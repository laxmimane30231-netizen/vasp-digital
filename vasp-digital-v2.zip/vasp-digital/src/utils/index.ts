/**
 * Format a date string to a readable format.
 * e.g. "2024-03-12" → "March 12, 2024"
 */
export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-CA', { year: 'numeric', month: 'long', day: 'numeric' });
}

/**
 * Estimate reading time from word count.
 */
export function readingTime(text: string): string {
  const words = text.split(/\s+/).length;
  const minutes = Math.ceil(words / 200);
  return `${minutes} min read`;
}

/**
 * Truncate text to a given length.
 */
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength).replace(/\s+\S*$/, '') + '…';
}

/**
 * Convert a string to a URL-safe slug.
 */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();
}

/**
 * Build canonical URL for a given path.
 */
export function canonicalUrl(path: string): string {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://vaspdigital.com';
  return `${base}${path.startsWith('/') ? path : `/${path}`}`;
}

/**
 * Build OG image URL via a service like Vercel OG or a static fallback.
 */
export function ogImageUrl(title: string): string {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://vaspdigital.com';
  return `${base}/api/og?title=${encodeURIComponent(title)}`;
}
