import Stripe from 'stripe';

// Singleton Stripe instance (server-only)
let stripeInstance: Stripe | null = null;

export function getStripe(): Stripe {
  if (!stripeInstance) {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key || key === 'sk_test_placeholder') {
      throw new Error('STRIPE_SECRET_KEY is not configured. Add it to .env.local');
    }
    stripeInstance = new Stripe(key, { apiVersion: '2026-05-27.dahlia' });
  }
  return stripeInstance;
}

/**
 * Resolve the Stripe Price ID for a package + currency.
 * Returns a pre-created Price ID if available, otherwise creates a dynamic one.
 */
export async function resolveStripePriceId(
  stripe: Stripe,
  packageId: string,
  packageTitle: string,
  amount: number,
  currency: string,
  billingPeriod: 'one-time' | 'monthly' | 'annual',
  existingPriceIds?: Record<string, string>
): Promise<string> {
  // Use pre-created price if available
  const existing = existingPriceIds?.[currency.toUpperCase()];
  if (existing && existing.startsWith('price_')) return existing;

  // Create a price on the fly
  const priceData: Stripe.PriceCreateParams = {
    unit_amount: Math.round(amount * 100), // Stripe uses cents
    currency: currency.toLowerCase(),
    ...(billingPeriod === 'monthly'
      ? { recurring: { interval: 'month' } }
      : billingPeriod === 'annual'
      ? { recurring: { interval: 'year' } }
      : {}),
    product_data: {
      name: packageTitle,
      metadata: { packageId },
    },
  };

  const price = await stripe.prices.create(priceData);
  return price.id;
}
