-- VASP Digital — Supabase Database Schema
-- Run this in the Supabase SQL editor

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Contact Submissions
CREATE TABLE IF NOT EXISTS contact_submissions (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  created_at    TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL,
  phone         TEXT,
  company       TEXT,
  message       TEXT NOT NULL,
  source        TEXT,
  status        TEXT DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'closed')),
  ip_address    TEXT
);

CREATE INDEX idx_contact_created ON contact_submissions (created_at DESC);
ALTER TABLE contact_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can submit" ON contact_submissions FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Auth can read" ON contact_submissions FOR SELECT TO authenticated USING (true);

-- Leads
CREATE TABLE IF NOT EXISTS leads (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  created_at    TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  contact_id    UUID REFERENCES contact_submissions(id),
  source        TEXT,
  campaign      TEXT,
  medium        TEXT,
  keyword       TEXT,
  landing_page  TEXT,
  status        TEXT DEFAULT 'new' CHECK (status IN ('new', 'qualified', 'proposal', 'won', 'lost')),
  notes         TEXT
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth manages leads" ON leads FOR ALL TO authenticated USING (true);

-- ─── Orders (created by Stripe webhook) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
  id                   UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  created_at           TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  stripe_session_id    TEXT UNIQUE,
  stripe_customer_id   TEXT,
  stripe_subscription_id TEXT,
  customer_email       TEXT,
  package_id           TEXT,
  package_title        TEXT,
  package_type         TEXT,
  amount               NUMERIC(10,2),
  currency             TEXT DEFAULT 'CAD',
  status               TEXT DEFAULT 'pending' CHECK (status IN ('pending','completed','cancelled','refunded')),
  mode                 TEXT DEFAULT 'subscription' CHECK (mode IN ('payment','subscription'))
);

CREATE INDEX idx_orders_email ON orders (customer_email);
CREATE INDEX idx_orders_stripe_session ON orders (stripe_session_id);
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth manages orders" ON orders FOR ALL TO authenticated USING (true);
