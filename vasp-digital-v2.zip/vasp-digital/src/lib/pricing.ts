import { ServicePackage, CurrencyCode, CURRENCIES } from '@/types/packages';

/**
 * Get the best price for a package in the requested currency.
 * Priority: countryPricing match → baseCurrency (with conversion note) → basePrice
 */
export function getPackagePrice(
  pkg: ServicePackage,
  currencyCode: CurrencyCode
): { amount: number; currency: CurrencyCode; isExact: boolean } {
  // Check for an exact currency match in countryPricing
  const exact = pkg.countryPricing.find(cp => cp.currency === currencyCode);
  if (exact) return { amount: exact.price, currency: currencyCode, isExact: true };

  // Fall back to base price
  return { amount: pkg.basePrice, currency: pkg.baseCurrency, isExact: false };
}

/**
 * Format a price amount with currency symbol.
 */
export function formatPrice(amount: number, currencyCode: CurrencyCode): string {
  const { symbol } = CURRENCIES[currencyCode];
  return `${symbol}${amount.toLocaleString('en', { minimumFractionDigits: 0 })}`;
}

/**
 * Build the billing suffix string.
 */
export function billingLabel(period: ServicePackage['billingPeriod']): string {
  if (period === 'monthly') return '/mo';
  if (period === 'annual') return '/yr';
  return '';
}
