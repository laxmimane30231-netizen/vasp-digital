'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  CurrencyCode, Currency, CURRENCIES,
  COUNTRY_CURRENCY_MAP, DEFAULT_CURRENCY,
} from '@/types/packages';

interface UseCurrencyReturn {
  currency:     Currency;
  currencyCode: CurrencyCode;
  setCurrency:  (code: CurrencyCode) => void;
  formatPrice:  (amount: number) => string;
  isLoading:    boolean;
}

const STORAGE_KEY = 'vasp_currency';

async function detectCurrencyFromServer(): Promise<CurrencyCode> {
  try {
    // First: try our edge API (works on Vercel with no extra keys)
    const res = await fetch('/api/geo', { cache: 'no-store' });
    if (res.ok) {
      const data = await res.json();
      if (data.currency && CURRENCIES[data.currency as CurrencyCode]) {
        return data.currency as CurrencyCode;
      }
    }
  } catch {/* continue to fallback */}

  try {
    // Fallback: ipapi.co (free, no key needed for <1k req/day)
    const res = await fetch('https://ipapi.co/country/', { cache: 'no-store' });
    if (res.ok) {
      const country = (await res.text()).trim().toUpperCase();
      if (/^[A-Z]{2}$/.test(country)) {
        return COUNTRY_CURRENCY_MAP[country] ?? DEFAULT_CURRENCY;
      }
    }
  } catch {/* give up */}

  return DEFAULT_CURRENCY;
}

export function useCurrency(): UseCurrencyReturn {
  const [currencyCode, setCurrencyCode] = useState<CurrencyCode>(DEFAULT_CURRENCY);
  const [isLoading, setIsLoading]       = useState(true);

  useEffect(() => {
    // 1. Honor stored preference immediately (no flash)
    const stored = typeof window !== 'undefined'
      ? (localStorage.getItem(STORAGE_KEY) as CurrencyCode | null)
      : null;

    if (stored && CURRENCIES[stored]) {
      setCurrencyCode(stored);
      setIsLoading(false);
      return;
    }

    // 2. Detect by geo
    detectCurrencyFromServer().then(detected => {
      setCurrencyCode(detected);
      setIsLoading(false);
    });
  }, []);

  const setCurrency = useCallback((code: CurrencyCode) => {
    setCurrencyCode(code);
    localStorage.setItem(STORAGE_KEY, code);
  }, []);

  const formatPrice = useCallback((amount: number) => {
    const { symbol } = CURRENCIES[currencyCode];
    return `${symbol}${amount.toLocaleString('en', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
  }, [currencyCode]);

  return {
    currency:     CURRENCIES[currencyCode],
    currencyCode,
    setCurrency,
    formatPrice,
    isLoading,
  };
}
