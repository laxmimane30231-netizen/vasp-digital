import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black text-white">
      {/* Main Footer */}
      <div className="container py-16 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center font-bold text-xl tracking-tight mb-6">
              <span className="bg-white text-black px-2 py-0.5 rounded text-sm font-bold mr-1">VASP</span>
              <span>Digital</span>
            </Link>
            <p className="text-white/60 text-sm leading-relaxed max-w-xs">
              Digital marketing for local and small businesses. We help you get more leads through SEO, paid advertising, and better websites.
            </p>
            <div className="flex items-center gap-4 mt-6">
              <a href="mailto:hello@vaspdigital.com" className="text-sm text-white/60 hover:text-white transition-colors">
                hello@vaspdigital.com
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white/40 mb-4">Services</h4>
            <ul className="space-y-2.5">
              {[
                { label: 'SEO Services', href: '/services/seo' },
                { label: 'Local SEO', href: '/services/local-seo' },
                { label: 'GBP Optimisation', href: '/services/gbp-optimisation' },
                { label: 'Local Citations', href: '/services/local-citations' },
                { label: 'Google Ads', href: '/services/google-ads' },
                { label: 'Meta Ads', href: '/services/meta-ads' },
                { label: 'Web Design', href: '/services/web-design' },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-sm text-white/60 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white/40 mb-4">Company</h4>
            <ul className="space-y-2.5">
              {[
                { label: 'About', href: '/about' },
                { label: 'Team', href: '/team' },
                { label: 'Case Studies', href: '/case-studies' },
                { label: 'Blog', href: '/blog' },
                { label: 'Contact', href: '/contact' },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-sm text-white/60 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Locations */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white/40 mb-4">Locations</h4>
            <ul className="space-y-2.5">
              {[
                { label: 'London', href: '/locations/london' },
                { label: 'Toronto', href: '/locations/toronto' },
                { label: 'Mississauga', href: '/locations/mississauga' },
                { label: 'Hamilton', href: '/locations/hamilton' },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-sm text-white/60 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/40">
            © {new Date().getFullYear()} VASP Digital. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link href="/privacy-policy" className="text-xs text-white/40 hover:text-white/70 transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-xs text-white/40 hover:text-white/70 transition-colors">
              Terms
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
