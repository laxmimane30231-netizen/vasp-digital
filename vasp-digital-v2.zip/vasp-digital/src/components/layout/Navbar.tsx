'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { ChevronDown, X, Menu, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { NAV_SERVICES, NAV_INDUSTRIES, NAV_LOCATIONS, NAV_RESOURCES, type NavItem } from '@/constants';
import CurrencySelector from '@/components/ui/CurrencySelector';

type DropdownKey = 'services' | 'industries' | 'locations' | 'resources' | null;

const navGroups: Array<{ key: DropdownKey; label: string; items: NavItem[] }> = [
  { key: 'services',   label: 'Services',   items: NAV_SERVICES },
  { key: 'industries', label: 'Industries', items: NAV_INDUSTRIES },
  { key: 'locations',  label: 'Locations',  items: NAV_LOCATIONS },
  { key: 'resources',  label: 'Resources',  items: NAV_RESOURCES },
];

export default function Navbar() {
  const [scrolled, setScrolled]           = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<DropdownKey>(null);
  const [mobileOpen, setMobileOpen]       = useState(false);
  const [mobileExpanded, setMobileExpanded] = useState<string | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeAll = () => { setActiveDropdown(null); setMobileOpen(false); };

  return (
    <>
      <header className={cn(
        'fixed top-0 left-0 right-0 z-50 bg-white border-b border-black/10 transition-shadow duration-300',
        scrolled && 'shadow-sm',
      )}>
        <div className="container">
          <nav className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center font-bold text-xl tracking-tight" onClick={closeAll}>
              <span className="bg-black text-white px-2 py-0.5 rounded text-sm font-bold mr-1">VASP</span>
              <span>Digital</span>
            </Link>

            {/* Desktop nav */}
            <div className="hidden lg:flex items-center gap-1">
              {navGroups.map(({ key, label, items }) => (
                <div key={key} className="relative"
                  onMouseEnter={() => setActiveDropdown(key)}
                  onMouseLeave={() => setActiveDropdown(null)}
                >
                  <button className={cn(
                    'flex items-center gap-1 px-3 py-2 text-sm font-medium rounded-md transition-colors',
                    activeDropdown === key ? 'text-[#623ccc]' : 'text-black hover:text-[#623ccc]',
                  )}>
                    {label}
                    <ChevronDown size={14} className={cn('transition-transform duration-200', activeDropdown === key && 'rotate-180')} />
                  </button>

                  {activeDropdown === key && (
                    <div className="absolute top-full left-0 mt-1 bg-white border border-black/10 rounded-xl shadow-xl p-2 min-w-[280px] z-50">
                      {items.map((item) => (
                        <Link key={item.href} href={item.href}
                          className="flex items-start justify-between gap-3 px-3 py-3 rounded-lg hover:bg-[#f0ecff] transition-colors group"
                          onClick={closeAll}
                        >
                          <div>
                            <div className="text-sm font-semibold text-black group-hover:text-[#623ccc] transition-colors">{item.label}</div>
                            <div className="text-xs text-black/50 mt-0.5">{item.description}</div>
                          </div>
                          {item.isNew && (
                            <span className="shrink-0 text-[10px] font-semibold bg-[#623ccc] text-white px-1.5 py-0.5 rounded-full">New</span>
                          )}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <Link href="/contact" className="px-3 py-2 text-sm font-medium text-black hover:text-[#623ccc] transition-colors" onClick={closeAll}>
                Contact
              </Link>
            </div>

            {/* CTA buttons */}
            <div className="hidden lg:flex items-center gap-3">
              <CurrencySelector />
              <Link href="/contact" className="px-4 py-2 text-sm font-semibold border border-black/20 rounded-full hover:border-black transition-colors">
                Contact
              </Link>
              <Link href="/contact?type=call" className="px-4 py-2 text-sm font-semibold bg-black text-white rounded-full hover:bg-[#623ccc] transition-colors">
                Book call
              </Link>
            </div>

            {/* Mobile toggle */}
            <button className="lg:hidden p-2 rounded-md" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Toggle menu">
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </nav>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden bg-white border-t border-black/10 max-h-[80vh] overflow-y-auto">
            <div className="container py-4 space-y-1">
              {navGroups.map(({ key, label, items }) => (
                <div key={key}>
                  <button
                    className="flex items-center justify-between w-full px-3 py-3 text-sm font-semibold"
                    onClick={() => setMobileExpanded(mobileExpanded === key ? null : key)}
                  >
                    {label}
                    <ChevronDown size={14} className={cn('transition-transform duration-200', mobileExpanded === key && 'rotate-180')} />
                  </button>
                  {mobileExpanded === key && (
                    <div className="pl-4 pb-2 space-y-1">
                      {items.map((item) => (
                        <Link key={item.href} href={item.href}
                          className="block px-3 py-2 text-sm text-black/70 hover:text-[#623ccc] transition-colors"
                          onClick={closeAll}
                        >
                          {item.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <Link href="/contact" className="block px-3 py-3 text-sm font-semibold" onClick={closeAll}>Contact</Link>
              <div className="pt-3">
                <Link href="/contact?type=call"
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-black text-white text-sm font-semibold rounded-full"
                  onClick={closeAll}
                >
                  Book a call <ArrowRight size={14} />
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      {activeDropdown && <div className="fixed inset-0 z-40" onClick={() => setActiveDropdown(null)} />}
    </>
  );
}
