// JSON-LD Structured Data components for SEO
// Usage: import and render in page.tsx or layout.tsx

interface LocalBusinessProps {
  name?: string;
  url?: string;
  telephone?: string;
  email?: string;
  streetAddress?: string;
  city?: string;
  province?: string;
  postalCode?: string;
  country?: string;
}

export function LocalBusinessStructuredData({
  name = 'VASP Digital',
  url = 'https://vaspdigital.com',
  telephone = '+1-705-902-0000',
  email = 'hello@vaspdigital.com',
  streetAddress = '133 King Street',
  city = 'London',
  province = 'Ontario',
  postalCode = 'N6A 1KI',
  country = 'CA',
}: LocalBusinessProps) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'ProfessionalService',
    name,
    url,
    telephone,
    email,
    address: {
      '@type': 'PostalAddress',
      streetAddress,
      addressLocality: city,
      addressRegion: province,
      postalCode,
      addressCountry: country,
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: 42.9849,
      longitude: -81.2453,
    },
    openingHoursSpecification: [
      { '@type': 'OpeningHoursSpecification', dayOfWeek: ['Monday','Tuesday','Wednesday','Thursday','Friday'], opens: '09:00', closes: '17:00' },
    ],
    sameAs: [
      'https://www.facebook.com/vaspdigital',
      'https://www.linkedin.com/company/vaspdigital',
      'https://www.instagram.com/vaspdigital',
    ],
    priceRange: '$$',
    areaServed: [
      { '@type': 'City', name: 'London', containedInPlace: { '@type': 'AdministrativeArea', name: 'Ontario' } },
      { '@type': 'City', name: 'Toronto', containedInPlace: { '@type': 'AdministrativeArea', name: 'Ontario' } },
      { '@type': 'City', name: 'Mississauga', containedInPlace: { '@type': 'AdministrativeArea', name: 'Ontario' } },
    ],
    hasOfferCatalog: {
      '@type': 'OfferCatalog',
      name: 'Digital Marketing Services',
      itemListElement: [
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'SEO Services' } },
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Local SEO' } },
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Google Ads' } },
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Meta Ads' } },
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Web Design & Development' } },
      ],
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

interface FAQItem { question: string; answer: string }

export function FAQStructuredData({ items }: { items: FAQItem[] }) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map(item => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: { '@type': 'Answer', text: item.answer },
    })),
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}

interface BreadcrumbItem { name: string; url: string }

export function BreadcrumbStructuredData({ items }: { items: BreadcrumbItem[] }) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}

interface ArticleProps {
  title: string;
  description: string;
  publishDate: string;
  modifiedDate?: string;
  author?: string;
  imageUrl?: string;
  url: string;
}

export function ArticleStructuredData({ title, description, publishDate, modifiedDate, author = 'VASP Digital', imageUrl, url }: ArticleProps) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: title,
    description,
    datePublished: publishDate,
    dateModified: modifiedDate ?? publishDate,
    author: { '@type': 'Organization', name: author },
    publisher: {
      '@type': 'Organization',
      name: 'VASP Digital',
      logo: { '@type': 'ImageObject', url: 'https://vaspdigital.com/logo.png' },
    },
    mainEntityOfPage: { '@type': 'WebPage', '@id': url },
    ...(imageUrl && { image: imageUrl }),
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}
