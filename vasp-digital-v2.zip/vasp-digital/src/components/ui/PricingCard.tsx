'use client';

import { useState } from 'react';
import { Check, X, Sparkles, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useCurrencyContext } from '@/context/CurrencyContext';
import { getPackagePrice, formatPrice, billingLabel } from '@/lib/pricing';
import type { ServicePackage } from '@/types/packages';
import { cn } from '@/lib/utils';

interface PricingCardProps {
  pkg: ServicePackage;
  highlighted?: boolean;
}

export default function PricingCard({ pkg, highlighted = false }: PricingCardProps) {
  const { currencyCode } = useCurrencyContext();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { amount, currency, isExact } = getPackagePrice(pkg, currencyCode);
  const priceStr = formatPrice(amount, currency);
  const suffix   = billingLabel(pkg.billingPeriod);

  const handleCheckout = async () => {
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          packageId:  pkg.id,
          currency:   currencyCode,
          successUrl: `${window.location.origin}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl:  `${window.location.origin}/payment/cancelled`,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? 'Something went wrong. Please try again.');
        setLoading(false);
        return;
      }

      // Redirect to Stripe Checkout
      if (data.url) {
        window.location.href = data.url;
        return;
      }

      // If no URL returned, Stripe is not configured
      setError('Stripe is not configured. Please add your Stripe keys to .env.local.');
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const isPopular = pkg.isPopular || highlighted;

  return (
    <motion.div
      className={cn(
        'relative rounded-2xl border flex flex-col overflow-hidden transition-shadow',
        isPopular
          ? 'border-[#623ccc] shadow-[0_0_0_2px_#623ccc] bg-white'
          : 'border-black/10 bg-white hover:shadow-md'
      )}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      whileHover={{ y: -3 }}
    >
      {/* Popular badge */}
      {isPopular && (
        <div className="bg-[#623ccc] text-white text-center py-2 text-xs font-semibold tracking-wide flex items-center justify-center gap-1.5">
          <Sparkles size={12} />
          Most Popular
        </div>
      )}

      <div className="p-7 flex flex-col flex-1">
        {/* Header */}
        <div className="mb-5">
          <h3 className="text-lg font-bold tracking-tight mb-1">{pkg.title}</h3>
          <p className="text-black/55 text-sm leading-relaxed">{pkg.description}</p>
        </div>

        {/* Price */}
        <div className="mb-6">
          <div className="flex items-end gap-1">
            <span className="text-4xl font-black tracking-tight">{priceStr}</span>
            {suffix && <span className="text-black/50 text-sm mb-1.5">{suffix}</span>}
          </div>
          {!isExact && (
            <p className="text-xs text-black/35 mt-1">
              Displayed in {currency} — local pricing may vary
            </p>
          )}
        </div>

        {/* Features */}
        <ul className="space-y-2.5 mb-7 flex-1">
          {pkg.features.map((feat, i) => (
            <li key={i} className="flex items-start gap-2.5">
              {feat.included ? (
                <Check size={15} className="text-[#623ccc] shrink-0 mt-0.5" />
              ) : (
                <X size={15} className="text-black/25 shrink-0 mt-0.5" />
              )}
              <span className={cn('text-sm leading-snug', !feat.included && 'text-black/35 line-through')}>
                {feat.text}
              </span>
            </li>
          ))}
        </ul>

        {/* CTA */}
        {error && (
          <p className="text-xs text-red-500 mb-3 leading-relaxed bg-red-50 rounded-lg p-2.5">{error}</p>
        )}
        <button
          onClick={handleCheckout}
          disabled={loading}
          className={cn(
            'w-full py-3 px-6 rounded-full font-semibold text-sm flex items-center justify-center gap-2 transition-all',
            isPopular
              ? 'bg-[#623ccc] text-white hover:bg-[#4f2ea8]'
              : 'bg-black text-white hover:bg-[#623ccc]',
            loading && 'opacity-70 cursor-not-allowed'
          )}
        >
          {loading ? (
            <><Loader2 size={15} className="animate-spin" /> Processing…</>
          ) : (
            pkg.buttonText
          )}
        </button>
      </div>
    </motion.div>
  );
}
