'use client';

import { useState, useRef, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import { useCurrencyContext } from '@/context/CurrencyContext';
import { CURRENCIES, CurrencyCode } from '@/types/packages';
import { cn } from '@/lib/utils';

interface CurrencySelectorProps {
  light?: boolean;
  className?: string;
}

export default function CurrencySelector({ light = false, className }: CurrencySelectorProps) {
  const { currencyCode, setCurrency, currency } = useCurrencyContext();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <div ref={ref} className={cn('relative', className)}>
      <button
        onClick={() => setOpen(o => !o)}
        className={cn(
          'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors',
          light
            ? 'text-white/70 hover:text-white hover:bg-white/10'
            : 'text-black/60 hover:text-black border border-black/15 hover:border-black/30'
        )}
      >
        <span>{currency.symbol}</span>
        <span>{currency.code}</span>
        <ChevronDown size={12} className={cn('transition-transform', open && 'rotate-180')} />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1.5 bg-white border border-black/10 rounded-xl shadow-xl p-1.5 min-w-[160px] z-50">
          {(Object.keys(CURRENCIES) as CurrencyCode[]).map(code => {
            const c = CURRENCIES[code];
            return (
              <button
                key={code}
                onClick={() => { setCurrency(code); setOpen(false); }}
                className={cn(
                  'w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors',
                  code === currencyCode
                    ? 'bg-[#f0ecff] text-[#623ccc] font-semibold'
                    : 'hover:bg-[#f1f1f1] text-black'
                )}
              >
                <span className="font-medium">{c.symbol} {c.code}</span>
                <span className="text-xs text-black/40">{c.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
