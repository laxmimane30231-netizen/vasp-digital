import { cn } from '@/lib/utils';

interface SectionLabelProps {
  children: React.ReactNode;
  className?: string;
  light?: boolean;
}

export default function SectionLabel({ children, className, light = false }: SectionLabelProps) {
  return (
    <span
      className={cn(
        'text-xs font-semibold uppercase tracking-widest',
        light ? 'text-white/60' : 'text-black/50',
        className
      )}
    >
      {children}
    </span>
  );
}
