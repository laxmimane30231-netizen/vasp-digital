import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import { BreadcrumbStructuredData } from '@/components/seo/StructuredData';

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
  light?: boolean;
}

export default function Breadcrumb({ items, light = false }: BreadcrumbProps) {
  const structuredItems = [
    { name: 'Home', url: 'https://vaspdigital.com' },
    ...items.map(item => ({ name: item.label, url: `https://vaspdigital.com${item.href ?? ''}` })),
  ];

  return (
    <>
      <BreadcrumbStructuredData items={structuredItems} />
      <nav aria-label="Breadcrumb">
        <ol className="flex items-center flex-wrap gap-1.5">
          <li>
            <Link
              href="/"
              className={`text-xs font-medium transition-colors ${light ? 'text-white/50 hover:text-white' : 'text-black/40 hover:text-black'}`}
            >
              Home
            </Link>
          </li>
          {items.map((item, i) => (
            <li key={i} className="flex items-center gap-1.5">
              <ChevronRight size={12} className={light ? 'text-white/30' : 'text-black/30'} />
              {item.href && i < items.length - 1 ? (
                <Link
                  href={item.href}
                  className={`text-xs font-medium transition-colors ${light ? 'text-white/50 hover:text-white' : 'text-black/40 hover:text-black'}`}
                >
                  {item.label}
                </Link>
              ) : (
                <span className={`text-xs font-medium ${light ? 'text-white/80' : 'text-black/70'}`}>
                  {item.label}
                </span>
              )}
            </li>
          ))}
        </ol>
      </nav>
    </>
  );
}
