import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'white';
  size?: 'sm' | 'md' | 'lg';
  href?: string;
  onClick?: () => void;
  className?: string;
  arrow?: boolean;
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
}

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  onClick,
  className,
  arrow = false,
  type = 'button',
  disabled = false,
}: ButtonProps) {
  const base = 'inline-flex items-center justify-center gap-2 font-semibold rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#623ccc]';

  const variants = {
    primary: 'bg-[#623ccc] text-white hover:bg-[#4f2ea8] active:scale-[0.98]',
    secondary: 'bg-black text-white hover:bg-[#623ccc] active:scale-[0.98]',
    outline: 'border border-black/20 text-black hover:border-black hover:bg-black/5 active:scale-[0.98]',
    ghost: 'text-black hover:bg-black/5 active:scale-[0.98]',
    white: 'bg-white text-black hover:bg-[#f0ecff] active:scale-[0.98]',
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-sm',
    lg: 'px-8 py-4 text-base',
  };

  const classes = cn(base, variants[variant], sizes[size], disabled && 'opacity-50 cursor-not-allowed', className);

  const content = (
    <>
      {children}
      {arrow && <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" />}
    </>
  );

  if (href) {
    return (
      <Link href={href} className={cn(classes, 'group')}>
        {content}
      </Link>
    );
  }

  return (
    <button type={type} onClick={onClick} disabled={disabled} className={cn(classes, 'group')}>
      {content}
    </button>
  );
}
