import type { Metadata } from 'next';
import './globals.css';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { LocalBusinessStructuredData } from '@/components/seo/StructuredData';
import ScrollProgress from '@/components/ui/ScrollProgress';
import { CurrencyProvider } from '@/context/CurrencyContext';

export const metadata: Metadata = {
  title: {
    default: 'VASP Digital — Digital Marketing for Local Businesses',
    template: '%s | VASP Digital',
  },
  description: 'VASP Digital helps local and small businesses in London and the GTA get more leads through SEO, local search visibility, paid advertising, and better websites.',
  keywords: ['digital marketing', 'SEO', 'local SEO', 'Google Ads', 'London Ontario', 'GTA', 'web design'],
  metadataBase: new URL('https://vaspdigital.com'),
  alternates: { canonical: '/' },
  openGraph: {
    type: 'website',
    locale: 'en_CA',
    url: 'https://vaspdigital.com',
    siteName: 'VASP Digital',
    title: 'VASP Digital — Digital Marketing for Local Businesses',
    description: 'Get more leads through SEO, local search, paid advertising, and better websites.',
    images: [{ url: '/og-image.jpg', width: 1200, height: 630, alt: 'VASP Digital' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'VASP Digital — Digital Marketing for Local Businesses',
    description: 'Get more leads through SEO, local search, paid advertising, and better websites.',
    images: ['/og-image.jpg'],
  },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
  verification: {
    // google: 'your-google-verification-token',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <LocalBusinessStructuredData />
      </head>
      <body className="antialiased">
        <ScrollProgress />
        <CurrencyProvider>
          <Navbar />
          <main>{children}</main>
          <Footer />
        </CurrencyProvider>
      </body>
    </html>
  );
}
