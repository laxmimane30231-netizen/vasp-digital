import type { Metadata } from 'next';
import CaseStudiesHero from '@/sections/case-studies/CaseStudiesHero';
import CaseStudiesGrid from '@/sections/case-studies/CaseStudiesGrid';

export const metadata: Metadata = {
  title: 'Case Studies — Real Results',
  description: 'See how VASP Digital has helped local businesses grow through SEO, paid ads, and better websites.',
};

export default function CaseStudiesPage() {
  return (
    <>
      <CaseStudiesHero />
      <CaseStudiesGrid />
    </>
  );
}
