import type { Metadata } from 'next';
import CTASection from '@/sections/shared/CTASection';
import CaseStudyContent from '@/sections/case-studies/CaseStudyContent';

interface Props { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  return { title: slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()), description: 'Case study — VASP Digital' };
}

export default async function CaseStudyPage({ params }: Props) {
  const { slug } = await params;
  return (
    <>
      <CaseStudyContent slug={slug} />
      <CTASection title="Want results like this?" description="Let's talk about what we can do for your business." variant="purple" />
    </>
  );
}
