import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

interface Props { params: Promise<{ slug: string }> }

const locationData: Record<string, { city: string; description: string }> = {
  'london':      { city: 'London',      description: 'Helping London Ontario businesses get more leads through SEO, Google Maps, and paid advertising.' },
  'toronto':     { city: 'Toronto',     description: 'Compete and win in Canada\'s largest market. We help Toronto businesses dominate local search.' },
  'mississauga': { city: 'Mississauga', description: 'Local SEO and paid ads for Mississauga businesses looking to grow.' },
  'hamilton':    { city: 'Hamilton',    description: 'Digital marketing built for Hamilton businesses ready to grow.' },
  'brampton':    { city: 'Brampton',    description: 'SEO, local search, and paid ads for Brampton businesses.' },
  'oakville':    { city: 'Oakville',    description: 'Premium digital marketing for Oakville businesses.' },
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const data = locationData[slug] ?? { city: slug, description: '' };
  return {
    title: `Digital Marketing ${data.city} — Local SEO & Paid Ads`,
    description: data.description,
  };
}

export default async function CityPage({ params }: Props) {
  const { slug } = await params;
  const data = locationData[slug] ?? { city: slug.replace(/-/g, ' '), description: 'Digital marketing for local businesses.' };
  return (
    <>
      <ServiceHero
        label={`${data.city}, Ontario`}
        title={`Digital marketing for ${data.city} businesses`}
        description={data.description}
        variant="purple"
      />
      <ServiceFeatures
        label={`${data.city} services`}
        title={`How we grow ${data.city} businesses`}
        features={[
          { icon: 'MapPin',    title: `Local SEO in ${data.city}`,          description: `Rank in Google Maps and local search for ${data.city} keywords.` },
          { icon: 'Search',    title: 'Organic search',                     description: 'Build long-term visibility that drives leads month after month.' },
          { icon: 'Target',    title: 'Google Ads',                         description: `Target customers in ${data.city} who are ready to buy right now.` },
          { icon: 'Users',     title: 'Meta Ads',                           description: 'Reach your ideal audience on Facebook and Instagram.' },
          { icon: 'Monitor',   title: 'Web design',                         description: 'A modern website that converts visitors into customers.' },
          { icon: 'BarChart2', title: 'Monthly reporting',                  description: 'Track every lead and understand exactly what is working.' },
        ]}
      />
      <CTASection
        title={`Ready to grow your ${data.city} business?`}
        description={`Let's talk about getting you more leads in ${data.city}.`}
        variant="coral"
      />
    </>
  );
}
