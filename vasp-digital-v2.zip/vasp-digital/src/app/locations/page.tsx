import type { Metadata } from 'next';
import LocationsHero from '@/sections/locations/LocationsHero';
import LocationsGrid from '@/sections/locations/LocationsGrid';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Locations — Where We Serve',
  description: 'VASP Digital serves businesses across London, Toronto, Mississauga, Hamilton, and all of Ontario.',
};

export default function LocationsPage() {
  return (
    <>
      <LocationsHero />
      <LocationsGrid />
      <CTASection title="Not in the list?" description="We work with businesses across Ontario and beyond. Reach out." variant="purple" />
    </>
  );
}
