import { NextRequest, NextResponse } from 'next/server';
import { COUNTRY_CURRENCY_MAP, DEFAULT_CURRENCY, type CurrencyCode } from '@/types/packages';

export const runtime = 'edge';

export async function GET(req: NextRequest) {
  // Vercel automatically provides geo data via request headers
  const country =
    req.headers.get('x-vercel-ip-country') ??   // Vercel
    req.headers.get('cf-ipcountry') ??            // Cloudflare
    req.headers.get('x-country-code') ??          // Generic CDN
    'US';

  const currency: CurrencyCode = COUNTRY_CURRENCY_MAP[country.toUpperCase()] ?? DEFAULT_CURRENCY;

  return NextResponse.json(
    { country, currency },
    {
      headers: {
        'Cache-Control': 'public, max-age=3600', // Cache 1 hour per IP
        'Vary': 'x-vercel-ip-country, cf-ipcountry',
      },
    }
  );
}
