import { NextRequest, NextResponse } from 'next/server';
import { getPackages } from '@/services/packages';
import { getPackagePrice } from '@/lib/pricing';
import type { CurrencyCode, CheckoutSessionRequest } from '@/types/packages';

export async function POST(req: NextRequest) {
  try {
    const body: CheckoutSessionRequest = await req.json();
    const { packageId, currency, customerEmail, successUrl, cancelUrl, metadata } = body;

    if (!packageId || !currency) {
      return NextResponse.json({ error: 'packageId and currency are required' }, { status: 400 });
    }

    // ── Guard: Stripe must be configured ─────────────────────────────────
    const secretKey = process.env.STRIPE_SECRET_KEY;
    if (!secretKey || secretKey === 'sk_test_placeholder') {
      return NextResponse.json(
        { error: 'Stripe is not configured. Add STRIPE_SECRET_KEY to your environment variables.' },
        { status: 503 }
      );
    }

    // ── Fetch package data ────────────────────────────────────────────────
    const packages = await getPackages();
    const pkg = packages.find(p => p.id === packageId || p.slug === packageId);
    if (!pkg) {
      return NextResponse.json({ error: `Package not found: ${packageId}` }, { status: 404 });
    }

    // ── Resolve price ─────────────────────────────────────────────────────
    const { amount, currency: resolvedCurrency } = getPackagePrice(pkg, currency as CurrencyCode);

    // ── Build Stripe session ──────────────────────────────────────────────
    const { getStripe, resolveStripePriceId } = await import('@/lib/stripe');
    const stripe = getStripe();

    const priceId = await resolveStripePriceId(
      stripe,
      pkg.id,
      pkg.title,
      amount,
      resolvedCurrency,
      pkg.billingPeriod,
      pkg.stripePriceIds
    );

    const baseUrl = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000';

    const session = await stripe.checkout.sessions.create({
      mode: pkg.billingPeriod === 'one-time' ? 'payment' : 'subscription',
      line_items: [{ price: priceId, quantity: 1 }],
      ...(customerEmail ? { customer_email: customerEmail } : {}),
      success_url: successUrl ?? `${baseUrl}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:  cancelUrl  ?? `${baseUrl}/payment/cancelled`,
      metadata: {
        packageId: pkg.id,
        packageTitle: pkg.title,
        packageType: pkg.packageType,
        currency: resolvedCurrency,
        ...metadata,
      },
      allow_promotion_codes: true,
    });

    return NextResponse.json({ sessionId: session.id, url: session.url });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    console.error('Stripe checkout error:', message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
