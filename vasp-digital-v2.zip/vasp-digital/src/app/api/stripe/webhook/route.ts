import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

export const runtime = 'nodejs'; // webhooks need Node.js (not Edge) for raw body

export async function POST(req: NextRequest) {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret || webhookSecret === 'whsec_placeholder') {
    return NextResponse.json({ error: 'Webhook secret not configured' }, { status: 503 });
  }

  const signature = req.headers.get('stripe-signature');
  if (!signature) {
    return NextResponse.json({ error: 'Missing stripe-signature header' }, { status: 400 });
  }

  let event: Stripe.Event;
  const body = await req.text();

  try {
    const { getStripe } = await import('@/lib/stripe');
    const stripe = getStripe();
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Webhook verification failed';
    console.error('Webhook error:', msg);
    return NextResponse.json({ error: msg }, { status: 400 });
  }

  // ── Handle events ────────────────────────────────────────────────────────
  try {
    switch (event.type) {

      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutComplete(session);
        break;
      }

      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const sub = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdate(sub);
        break;
      }

      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        await handleSubscriptionCancelled(sub);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        await handlePaymentFailed(invoice);
        break;
      }

      default:
        console.log(`Unhandled webhook event: ${event.type}`);
    }

    return NextResponse.json({ received: true });
  } catch (err) {
    console.error('Webhook handler error:', err);
    return NextResponse.json({ error: 'Handler failed' }, { status: 500 });
  }
}

// ─── Event Handlers ────────────────────────────────────────────────────────

async function handleCheckoutComplete(session: Stripe.Checkout.Session) {
  console.log('✅ Payment complete:', {
    sessionId: session.id,
    customer: session.customer_email,
    amount: session.amount_total,
    currency: session.currency,
    packageId: session.metadata?.packageId,
    packageTitle: session.metadata?.packageTitle,
  });

  // TODO: Save order to Supabase
  try {
    const { createClient } = await import('@/lib/supabase/server');
    const supabase = await createClient();
    await supabase.from('orders').upsert({
      stripe_session_id: session.id,
      stripe_customer_id: session.customer as string,
      customer_email: session.customer_email,
      package_id: session.metadata?.packageId,
      package_title: session.metadata?.packageTitle,
      package_type: session.metadata?.packageType,
      amount: (session.amount_total ?? 0) / 100,
      currency: session.currency?.toUpperCase(),
      status: 'completed',
      mode: session.mode,
    });
  } catch (err) {
    console.warn('Could not save order to Supabase (table may not exist yet):', err);
  }
}

async function handleSubscriptionUpdate(subscription: Stripe.Subscription) {
  console.log('🔄 Subscription updated:', subscription.id, subscription.status);
  // TODO: Update subscription status in Supabase
}

async function handleSubscriptionCancelled(subscription: Stripe.Subscription) {
  console.log('❌ Subscription cancelled:', subscription.id);
  // TODO: Handle cancellation — revoke access, send email
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  console.log('⚠️ Payment failed:', invoice.id, invoice.customer_email);
  // TODO: Send retry email
}
