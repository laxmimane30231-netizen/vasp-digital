import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, phone, company, message, source } = body;

    // Validate required fields
    if (!name || !email || !message) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: 'Invalid email address' }, { status: 400 });
    }

    // Save to Supabase
    const { createClient } = await import('@/lib/supabase/server');
    const supabase = await createClient();

    const { error: dbError } = await supabase
      .from('contact_submissions')
      .insert({
        name: name.trim(),
        email: email.trim().toLowerCase(),
        phone: phone?.trim() ?? null,
        company: company?.trim() ?? null,
        message: message.trim(),
        source: source ?? 'contact',
        ip_address: request.headers.get('x-forwarded-for') ?? request.headers.get('x-real-ip') ?? null,
      });

    if (dbError) {
      console.error('Supabase insert error:', dbError);
      // Don't expose DB errors to client — fail silently and still return success
      // (form still submitted, just not saved — log this in monitoring)
    }

    // TODO: Send notification email via Resend/SendGrid
    // await sendNotificationEmail({ name, email, message });

    return NextResponse.json({ success: true, message: 'Message received. We will be in touch within 24 hours.' });
  } catch (error) {
    console.error('Contact API error:', error);
    return NextResponse.json({ error: 'Something went wrong. Please try again.' }, { status: 500 });
  }
}
