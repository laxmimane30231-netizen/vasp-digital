import { ImageResponse } from 'next/og';
import { NextRequest } from 'next/server';

export const runtime = 'edge';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const title = searchParams.get('title') ?? 'VASP Digital';
  const subtitle = searchParams.get('subtitle') ?? 'Digital Marketing for Local Businesses';

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-end',
          padding: '60px',
          background: '#623ccc',
          fontFamily: 'sans-serif',
        }}
      >
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 'auto' }}>
          <div style={{ background: 'white', color: '#623ccc', padding: '6px 12px', borderRadius: '6px', fontWeight: 900, fontSize: 20, marginRight: 8 }}>
            VASP
          </div>
          <span style={{ color: 'white', fontWeight: 700, fontSize: 20 }}>Digital</span>
        </div>

        {/* Title */}
        <div style={{ color: 'white', fontSize: 52, fontWeight: 800, lineHeight: 1.1, marginBottom: 16, maxWidth: 900 }}>
          {title}
        </div>

        {/* Subtitle */}
        <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 24, fontWeight: 400 }}>
          {subtitle}
        </div>
      </div>
    ),
    { width: 1200, height: 630 }
  );
}
