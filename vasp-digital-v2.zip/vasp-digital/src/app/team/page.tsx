import type { Metadata } from 'next';
import CTASection from '@/sections/shared/CTASection';
import TeamHero from '@/sections/team/TeamHero';
import TeamGrid from '@/sections/team/TeamGrid';

export const metadata: Metadata = {
  title: 'Team',
  description: 'Meet the VASP Digital team. The people behind your growth.',
};

export default function TeamPage() {
  return (
    <>
      <TeamHero />
      <TeamGrid />
      <CTASection title="Work with our team" description="Let's talk about growing your business." variant="purple" />
    </>
  );
}
