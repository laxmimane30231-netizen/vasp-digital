import type { Metadata } from 'next';
import ContactHero from '@/sections/contact/ContactHero';
import ContactInfo from '@/sections/contact/ContactInfo';
import ContactForm from '@/sections/contact/ContactForm';

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with VASP Digital. Tell us about your business and we'll show you how we can help you grow.",
};

export default function ContactPage() {
  return (
    <>
      <ContactHero />
      <ContactInfo />
      <ContactForm />
    </>
  );
}
