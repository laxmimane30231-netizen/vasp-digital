import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';
import TestimonialsSection from '@/sections/home/TestimonialsSection';

interface Props { params: Promise<{ slug: string }> }

const industryData: Record<string, { name: string; description: string }> = {
  'clinics': { name: 'Clinics & Healthcare', description: 'Get more patients through local search and Google Ads.' },
  'contractors': { name: 'Contractors & Trades', description: 'Get qualified leads from people ready to hire a contractor in your area.' },
  'legal': { name: 'Legal Services', description: 'Build authority and attract high-value clients through SEO and paid advertising.' },
  'real-estate': { name: 'Real Estate', description: 'Dominate local search and attract buyers and sellers in your market.' },
  'restaurants': { name: 'Restaurants & Food', description: 'Get found when hungry locals search. Drive reservations and walk-ins.' },
  'home-services': { name: 'Home Services', description: 'Show up when homeowners need you. Get more service calls.' },
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const data = industryData[slug] ?? { name: slug, description: '' };
  return { title: data.name, description: data.description };
}

export default async function IndustryPage({ params }: Props) {
  const { slug } = await params;
  const data = industryData[slug] ?? { name: slug.replace(/-/g, ' '), description: 'Digital marketing for your industry.' };
  return (
    <>
      <ServiceHero
        label={data.name}
        title={`Digital marketing for ${data.name.toLowerCase()}`}
        description={data.description}
        variant="coral"
      />
      <ServiceFeatures
        label="What we do"
        title={`How we grow ${data.name.toLowerCase()}`}
        features={[
          { icon: 'Search',     title: 'Local SEO',          description: 'Rank where your customers are searching.' },
          { icon: 'MapPin',     title: 'Google Maps',        description: 'Dominate the local pack in your area.' },
          { icon: 'Target',     title: 'Targeted ads',       description: 'Reach customers ready to buy right now.' },
          { icon: 'Monitor',    title: 'Website that converts', description: 'A site built to turn visitors into clients.' },
          { icon: 'Star',       title: 'Review generation',  description: 'Build the social proof that drives trust.' },
          { icon: 'BarChart2',  title: 'Monthly reporting',  description: 'Clear tracking of every lead and result.' },
        ]}
      />
      <TestimonialsSection />
      <CTASection title={`Ready to grow your ${data.name.toLowerCase()} business?`} description="Let's talk about getting you more leads." variant="purple" />
    </>
  );
}
