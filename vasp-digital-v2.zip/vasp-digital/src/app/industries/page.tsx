import type { Metadata } from 'next';
import IndustriesHero from '@/sections/industries/IndustriesHero';
import IndustriesGrid from '@/sections/industries/IndustriesGrid';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Industries',
  description: 'Digital marketing for clinics, contractors, legal firms, real estate, and more. We know your market.',
};

export default function IndustriesPage() {
  return (
    <>
      <IndustriesHero />
      <IndustriesGrid />
      <CTASection title="Don't see your industry?" description="We work with all kinds of local businesses. Let's talk." variant="coral" />
    </>
  );
}
