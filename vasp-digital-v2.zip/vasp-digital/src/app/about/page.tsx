import type { Metadata } from 'next';
import CTASection from '@/sections/shared/CTASection';
import AboutHero from '@/sections/about/AboutHero';
import AboutValues from '@/sections/about/AboutValues';
import AboutTeamPreview from '@/sections/about/AboutTeamPreview';

export const metadata: Metadata = {
  title: 'About',
  description: 'We are a digital marketing agency focused on helping local and small businesses grow through SEO, paid advertising, and better websites.',
};

export default function AboutPage() {
  return (
    <>
      <AboutHero />
      <AboutValues />
      <AboutTeamPreview />
      <CTASection title="Work with us" description="Let's build something that grows your business." variant="purple" />
    </>
  );
}
