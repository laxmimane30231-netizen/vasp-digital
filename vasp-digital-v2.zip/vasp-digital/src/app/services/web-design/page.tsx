import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Web Design & Development',
  description: 'Build websites that convert visitors into customers. Fast, modern, SEO-ready websites for local businesses.',
};

export default function WebDesignPage() {
  return (
    <>
      <ServiceHero
        label="Web Design"
        title="Build websites that convert"
        description="Fast, modern websites designed to turn visitors into paying customers. Built on WordPress and modern frameworks, optimized for speed and search."
        variant="dark"
      />
      <ServiceFeatures
        label="What's included"
        title="Everything a great website needs"
        features={[
          { icon: 'Monitor',    title: 'Custom design',   description: 'Designed from scratch to match your brand and convert your audience.' },
          { icon: 'Smartphone', title: 'Mobile-first',    description: 'Looks perfect on every device — phone, tablet, desktop.' },
          { icon: 'Zap',        title: 'Fast loading',    description: 'Optimized for Core Web Vitals and Google PageSpeed.' },
          { icon: 'Search',     title: 'SEO-ready',       description: 'Built with search in mind from day one.' },
          { icon: 'Shield',     title: 'Secure & reliable',description: 'SSL, regular backups, and uptime monitoring.' },
          { icon: 'RefreshCw',  title: 'Easy to update',  description: 'CMS-powered so you can manage your own content.' },
        ]}
      />
      <CTASection title="Ready for a new website?" description="Get a site that works as hard as you do." variant="purple" />
    </>
  );
}
