import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import PricingSection from '@/sections/shared/PricingSection';
import TestimonialsSection from '@/sections/home/TestimonialsSection';
import FAQSection from '@/sections/home/FAQSection';
import CTASection from '@/sections/shared/CTASection';
import { getPackages } from '@/services/packages';

export const metadata: Metadata = {
  title: 'SEO Services & Packages — Rank Higher in Google',
  description: 'Transparent SEO pricing. Choose the package that fits your business and budget. No contracts.',
};

export default async function SEOServicesPage() {
  const packages = await getPackages('seo');

  return (
    <>
      <ServiceHero
        label="SEO Services"
        title="Rank higher and own your search results"
        description="We build SEO strategies that put your business in front of people actively searching for what you offer. Steady, sustainable growth that compounds over time."
        variant="purple"
      />
      <ServiceFeatures
        label="What we do"
        title="Everything you need to rank and grow"
        description="Our SEO work covers every angle — technical, content, and authority — so your rankings stick and compound over time."
        features={[
          { icon: 'Search',     title: 'Keyword research',    description: 'Find the exact search terms your best customers use.' },
          { icon: 'FileText',   title: 'On-page SEO',         description: 'Optimize every page for search intent and relevance.' },
          { icon: 'Link2',      title: 'Link building',       description: 'Earn authority through high-quality backlinks.' },
          { icon: 'TrendingUp', title: 'Technical SEO',       description: 'Fix crawling, indexing, and speed issues.' },
          { icon: 'MapPin',     title: 'Local SEO',           description: 'Dominate local search for your city.' },
          { icon: 'BarChart2',  title: 'Monthly reporting',   description: 'Clear reports on rankings, traffic, and leads.' },
        ]}
      />
      <PricingSection
        title="SEO packages"
        description="Transparent pricing. No hidden fees. Cancel monthly plans anytime."
        packages={packages}
        bgColor="bg-[#f0ecff]"
      />
      <TestimonialsSection />
      <FAQSection />
      <CTASection title="Not sure which plan?" description="Book a free call and we'll recommend the right package for your business." variant="purple" />
    </>
  );
}
