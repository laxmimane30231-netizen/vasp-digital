import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Local Citations — Build Your Online Presence',
  description: 'Get your business listed consistently across directories to boost local SEO and build trust with Google.',
};

export default function LocalCitationsPage() {
  return (
    <>
      <ServiceHero label="Local Citations" title="Build the foundation for local SEO" description="Consistent business listings across directories tell Google you are legitimate and local. We build and clean up citations so your rankings improve." variant="dark" />
      <ServiceFeatures label="Citation services" title="Everything citations need" features={[
        { icon: 'Building2', title: 'Directory submissions', description: 'Get listed on the top 50+ local directories that matter.' },
        { icon: 'Search', title: 'NAP consistency', description: 'Ensure name, address, phone match everywhere online.' },
        { icon: 'RefreshCw', title: 'Citation cleanup', description: 'Fix incorrect or duplicate listings that harm rankings.' },
        { icon: 'Globe', title: 'Industry directories', description: 'Listings on niche directories specific to your industry.' },
        { icon: 'BarChart2', title: 'Citation audit', description: 'Full audit of where you are listed and what needs fixing.' },
        { icon: 'Shield', title: 'Ongoing monitoring', description: 'Alerts when listings change or new duplicates appear.' },
      ]} />
      <CTASection title="Build your local presence" description="Start with a free citation audit." variant="coral" />
    </>
  );
}
