import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Paid Ads — Google Ads & Meta Ads',
  description: 'Fast results when you need them. We run Google Ads and Meta campaigns that target the right people at the right time.',
};

export default function PaidAdsPage() {
  return (
    <>
      <ServiceHero
        label="Paid Ads"
        title="Drive qualified leads with Google and Meta ads"
        description="Fast results when you need them. We run Google Ads and Meta campaigns that target the right people at the right time, turning clicks into customers."
        variant="purple"
      />
      <ServiceFeatures
        label="Our approach"
        title="Ads that actually convert"
        features={[
          { icon: 'Target',     title: 'Campaign strategy',    description: 'Build the right structure for your goals, budget, and audience.' },
          { icon: 'Users',      title: 'Audience targeting',   description: 'Find people ready to buy — not just browsers.' },
          { icon: 'DollarSign', title: 'Bid management',       description: 'Maximize ROI with smart bidding strategies.' },
          { icon: 'Zap',        title: 'Ad creative',          description: 'Copy and creative that stops the scroll and drives clicks.' },
          { icon: 'BarChart2',  title: 'Conversion tracking',  description: 'Track every lead, call, and form submission back to the ad.' },
          { icon: 'RefreshCw',  title: 'Ongoing optimisation', description: 'Weekly adjustments to keep costs down and results up.' },
        ]}
      />
      <CTASection title="Start driving leads today" description="Launch your first campaign this week." variant="black" />
    </>
  );
}
