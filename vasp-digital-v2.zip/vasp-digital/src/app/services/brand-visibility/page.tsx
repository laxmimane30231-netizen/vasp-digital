import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Brand Visibility — Get Seen Everywhere Locally',
  description: 'Build consistent brand presence across search, social, and local directories so more people know your name before they ever need you.',
};

export default function BrandVisibilityPage() {
  return (
    <>
      <ServiceHero
        label="Brand Visibility"
        title="Get your business seen everywhere that matters"
        description="Build consistent brand presence across search, social, and local directories so more people know your name before they ever need you."
        variant="purple"
      />
      <ServiceFeatures
        label="What we cover"
        title="Visibility across every channel"
        features={[
          { icon: 'Search',     title: 'Search presence',      description: 'Dominate organic and local search results for your key terms.' },
          { icon: 'MapPin',     title: 'Google Maps',          description: 'Stay visible in the local pack when customers search nearby.' },
          { icon: 'Globe',      title: 'Directory listings',   description: 'Consistent, accurate listings across 50+ directories.' },
          { icon: 'Star',       title: 'Review profile',       description: 'A strong review presence that builds trust at first glance.' },
          { icon: 'Users',      title: 'Social presence',      description: 'Consistent brand across Facebook, Instagram, and LinkedIn.' },
          { icon: 'BarChart2',  title: 'Visibility tracking',  description: 'Monthly reports showing reach, impressions, and brand mentions.' },
        ]}
      />
      <CTASection title="Build your brand visibility" description="Start getting seen in all the right places." variant="coral" />
    </>
  );
}
