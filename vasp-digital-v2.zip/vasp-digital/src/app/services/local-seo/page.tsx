import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import PricingSection from '@/sections/shared/PricingSection';
import CTASection from '@/sections/shared/CTASection';
import { getPackages } from '@/services/packages';

export const metadata: Metadata = {
  title: 'Local SEO Services & Packages — Dominate Local Search',
  description: 'Local SEO packages for businesses that want to rank in Google Maps and local search. Transparent pricing.',
};

export default async function LocalSEOPage() {
  const packages = await getPackages('local-seo');

  return (
    <>
      <ServiceHero
        label="Local SEO"
        title="Get found when customers search near you"
        description="Dominate local search results and Google Maps. We optimize your profile, citations, and local signals so customers in your area find you first."
        variant="dark"
      />
      <ServiceFeatures
        label="Local SEO services"
        title="Own your local market"
        features={[
          { icon: 'MapPin',    title: 'Google Business Profile', description: 'Optimise your GBP to rank in the local pack and get more calls.' },
          { icon: 'Star',      title: 'Review management',       description: 'Build a steady stream of 5-star reviews that boost rankings.' },
          { icon: 'Building2', title: 'Local citations',         description: 'Get listed on the right directories with consistent NAP data.' },
          { icon: 'Globe',     title: 'Localised content',       description: 'Pages that rank for city-specific searches.' },
          { icon: 'Phone',     title: 'Call tracking',           description: 'Know exactly which searches are driving phone calls.' },
          { icon: 'TrendingUp',title: 'Competitor analysis',     description: 'See what competitors rank for and beat them.' },
        ]}
      />
      <PricingSection
        title="Local SEO packages"
        description="Dominate your local market. Pricing shown in your currency."
        packages={packages}
        bgColor="bg-white"
      />
      <CTASection title="Ready to dominate local search?" description="Start getting found in your area today." variant="coral" />
    </>
  );
}
