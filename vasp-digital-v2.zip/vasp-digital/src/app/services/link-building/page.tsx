import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import PricingSection from '@/sections/shared/PricingSection';
import CTASection from '@/sections/shared/CTASection';
import { getPackages } from '@/services/packages';

export const metadata: Metadata = {
  title: 'Link Building Packages — Build Domain Authority',
  description: 'Quality link building packages that improve your domain authority and Google rankings. Transparent pricing.',
};

export default async function LinkBuildingPage() {
  const packages = await getPackages('link-building');

  return (
    <>
      <ServiceHero
        label="Link Building"
        title="Build authority with quality backlinks"
        description="Earn links from relevant, high-authority websites that Google trusts. Every link is manually placed — no spam, no shortcuts."
        variant="purple"
      />
      <ServiceFeatures
        label="How we build links"
        title="Quality over quantity, every time"
        features={[
          { icon: 'Link2',      title: 'Manual outreach',       description: 'Every link is built through genuine relationship outreach.' },
          { icon: 'Shield',     title: 'DR 30+ domains',        description: 'We only place links on domains with real authority.' },
          { icon: 'Globe',      title: 'Niche relevance',       description: 'Links from sites relevant to your industry and market.' },
          { icon: 'FileText',   title: 'Content included',      description: 'We write the guest posts so you don\'t have to.' },
          { icon: 'BarChart2',  title: 'Monthly link report',   description: 'Full report of every link built with metrics.' },
          { icon: 'TrendingUp', title: 'Ranking improvements',  description: 'Track the impact on your keyword rankings month over month.' },
        ]}
      />
      <PricingSection
        title="Link building packages"
        description="Consistent, quality links every month. No contracts required."
        packages={packages}
        bgColor="bg-[#f0ecff]"
      />
      <CTASection title="Start building authority" description="Let's discuss which link building package is right for you." variant="black" />
    </>
  );
}
