import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Lead Generation Ads',
  description: 'Capture qualified leads directly through paid advertising. Google, Meta, and display campaigns built to fill your pipeline.',
};

export default function LeadGenAdsPage() {
  return (
    <>
      <ServiceHero
        label="Lead Generation Ads"
        title="Fill your pipeline with qualified leads"
        description="Capture contact information from your ideal customers through targeted Google and Meta lead generation campaigns. Every lead tracked, every campaign optimised."
        variant="dark"
      />
      <ServiceFeatures
        label="Lead gen services"
        title="Campaigns built to capture leads"
        features={[
          { icon: 'Target',     title: 'Lead form ads',         description: 'Native lead forms inside Google and Meta that reduce friction.' },
          { icon: 'Users',      title: 'Audience targeting',    description: 'Reach people by job title, interests, location, and behaviour.' },
          { icon: 'Zap',        title: 'Landing page design',   description: 'High-converting pages paired with every campaign.' },
          { icon: 'DollarSign', title: 'Cost per lead tracking', description: 'Know exactly what each lead costs and optimise relentlessly.' },
          { icon: 'RefreshCw',  title: 'Lead nurture setup',    description: 'Automated follow-up sequences to convert leads into clients.' },
          { icon: 'BarChart2',  title: 'Weekly reporting',      description: 'Full transparency on every dollar and every lead.' },
        ]}
      />
      <CTASection title="Start filling your pipeline" description="Launch a lead generation campaign this week." variant="purple" />
    </>
  );
}
