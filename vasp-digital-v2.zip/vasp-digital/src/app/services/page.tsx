import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import CTASection from '@/sections/shared/CTASection';
import ServiceGrid from '@/sections/services/ServiceGrid';

export const metadata: Metadata = {
  title: 'Digital Marketing Services',
  description: 'SEO, local search, Google Ads, Meta Ads, and web design for local businesses. Four ways to grow your business online.',
};

export default function ServicesPage() {
  return (
    <>
      <ServiceHero
        label="Services"
        title="Digital marketing services that drive local business growth"
        description="We help small businesses and service companies get found on Google, attract qualified leads, and grow revenue through SEO, local SEO, paid advertising, and modern web design."
        variant="dark"
      />
      <ServiceGrid />
      <CTASection
        title="Not sure where to start?"
        description="Let's talk about what makes sense for your business right now."
        primaryCTA={{ label: 'Book a call', href: '/contact?type=call' }}
        secondaryCTA={{ label: 'Get a free audit', href: '/contact?type=audit' }}
        variant="purple"
      />
    </>
  );
}
