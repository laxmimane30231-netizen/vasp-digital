import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'WordPress Development',
  description: 'Custom WordPress websites built for speed, SEO, and conversions. For local businesses.',
};

export default function WordPressPage() {
  return (
    <>
      <ServiceHero label="WordPress Development" title="Custom WordPress websites that perform" description="Fast, SEO-optimized WordPress websites built for local businesses. Easy to manage, built to convert." variant="dark" />
      <ServiceFeatures label="What's included" title="WordPress done right" features={[
        { icon: 'Monitor', title: 'Custom theme design', description: 'Designed to match your brand, not a generic template.' },
        { icon: 'Zap', title: 'Speed optimization', description: 'Configured for Core Web Vitals and fast page loads.' },
        { icon: 'Search', title: 'SEO foundation', description: 'Yoast or RankMath configured, schema markup, sitemap.' },
        { icon: 'Shield', title: 'Security hardening', description: 'Wordfence, backups, SSL, and update management.' },
        { icon: 'Smartphone', title: 'Mobile responsive', description: 'Perfect on every screen size, every device.' },
        { icon: 'RefreshCw', title: 'Training included', description: 'We show you how to manage your content going forward.' },
      ]} />
      <CTASection title="Ready for a new WordPress site?" description="Let's build something you are proud of." variant="purple" />
    </>
  );
}
