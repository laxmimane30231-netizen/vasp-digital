import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Google Ads — Drive Qualified Leads Fast',
  description: 'Get in front of customers actively searching for your service with Google Ads managed by VASP Digital.',
};

export default function GoogleAdsPage() {
  return (
    <>
      <ServiceHero label="Google Ads" title="Get leads from Google search immediately" description="We set up, manage, and optimize Google Ads campaigns that target people actively searching for what you offer. Every dollar tracked, every lead counted." variant="dark" />
      <ServiceFeatures label="Google Ads services" title="Campaigns built to convert" features={[
        { icon: 'Search', title: 'Search campaigns', description: 'Show up when customers search your exact services.' },
        { icon: 'Target', title: 'Call-only ads', description: 'Drive phone calls directly from the search results.' },
        { icon: 'MapPin', title: 'Local service ads', description: 'Appear at the very top for local searches with Google Guarantee.' },
        { icon: 'BarChart2', title: 'Performance tracking', description: 'Know the cost per lead for every campaign.' },
        { icon: 'DollarSign', title: 'Budget control', description: 'Full transparency on where every dollar goes.' },
        { icon: 'RefreshCw', title: 'Weekly optimisation', description: 'Continuous improvements to lower cost and raise quality.' },
      ]} />
      <CTASection title="Start getting leads from Google" description="We can have your first campaign live within a week." variant="purple" />
    </>
  );
}
