import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Google Business Profile Optimisation',
  description: 'Optimise your Google Business Profile to rank higher in Google Maps and the local pack.',
};

export default function GBPPage() {
  return (
    <>
      <ServiceHero label="GBP Optimisation" title="Rank higher in Google Maps" description="Your Google Business Profile is your most powerful local marketing tool. We make sure it's set up to rank and convert." variant="dark" />
      <ServiceFeatures label="What we optimise" title="Every element of your GBP" features={[
        { icon: 'MapPin', title: 'Profile completion', description: 'Every field filled in correctly with keywords and local signals.' },
        { icon: 'Star', title: 'Review strategy', description: 'A system for generating genuine 5-star reviews consistently.' },
        { icon: 'Globe', title: 'Posts and updates', description: 'Regular posts that keep your profile active and relevant.' },
        { icon: 'Phone', title: 'Q&A management', description: 'Proactive answers to questions customers ask.' },
        { icon: 'Monitor', title: 'Photo optimisation', description: 'High-quality photos that improve engagement and trust.' },
        { icon: 'BarChart2', title: 'Insights tracking', description: 'Monitor calls, direction requests, and website clicks.' },
      ]} />
      <CTASection title="Rank higher in Google Maps" description="Let's audit and optimise your GBP this week." variant="purple" />
    </>
  );
}
