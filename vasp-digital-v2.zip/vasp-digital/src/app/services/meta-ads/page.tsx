import type { Metadata } from 'next';
import ServiceHero from '@/sections/services/ServiceHero';
import ServiceFeatures from '@/sections/services/ServiceFeatures';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'Meta Ads — Facebook & Instagram Advertising',
  description: 'Reach your ideal customers on Facebook and Instagram with targeted Meta Ads campaigns.',
};

export default function MetaAdsPage() {
  return (
    <>
      <ServiceHero label="Meta Ads" title="Reach your ideal customers on Facebook and Instagram" description="Meta Ads let you target by location, interests, and behaviour. Perfect for building brand awareness and generating leads in your local area." variant="purple" />
      <ServiceFeatures label="Meta Ads services" title="Social advertising that works" features={[
        { icon: 'Users', title: 'Audience building', description: 'Find your ideal customer using Meta\'s targeting tools.' },
        { icon: 'Zap', title: 'Creative that converts', description: 'Ad copy and visuals tested for your audience.' },
        { icon: 'Target', title: 'Lead generation ads', description: 'Capture leads directly inside Facebook and Instagram.' },
        { icon: 'RefreshCw', title: 'Retargeting', description: 'Re-engage people who visited your website.' },
        { icon: 'BarChart2', title: 'Performance reporting', description: 'Clear data on reach, clicks, leads, and cost.' },
        { icon: 'DollarSign', title: 'Budget efficiency', description: 'Maximize results from every dollar spent.' },
      ]} />
      <CTASection title="Reach more customers on social" description="Start your first Meta Ads campaign today." variant="coral" />
    </>
  );
}
