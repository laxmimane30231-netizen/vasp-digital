import { MetadataRoute } from 'next';

const BASE_URL = 'https://vaspdigital.com';

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = [
    { url: '/', priority: 1.0, changeFrequency: 'weekly' as const },
    { url: '/services', priority: 0.9, changeFrequency: 'monthly' as const },
    { url: '/services/seo', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/services/local-seo', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/services/paid-ads', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/services/google-ads', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/services/meta-ads', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/services/web-design', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/services/gbp-optimisation', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/services/local-citations', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/services/wordpress-development', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/services/link-building', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/services/brand-visibility', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/services/lead-generation-ads', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/industries', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/industries/clinics', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/industries/contractors', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/industries/legal', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/industries/real-estate', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/locations', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/locations/london', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/locations/toronto', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/locations/mississauga', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/locations/hamilton', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/about', priority: 0.7, changeFrequency: 'monthly' as const },
    { url: '/team', priority: 0.6, changeFrequency: 'monthly' as const },
    { url: '/blog', priority: 0.8, changeFrequency: 'weekly' as const },
    { url: '/case-studies', priority: 0.8, changeFrequency: 'monthly' as const },
    { url: '/contact', priority: 0.9, changeFrequency: 'monthly' as const },
  ];

  return pages.map(({ url, priority, changeFrequency }) => ({
    url: `${BASE_URL}${url}`,
    lastModified: new Date(),
    changeFrequency,
    priority,
  }));
}
