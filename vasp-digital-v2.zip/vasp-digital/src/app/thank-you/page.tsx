import type { Metadata } from 'next';
import ThankYouContent from '@/sections/contact/ThankYouContent';

export const metadata: Metadata = {
  title: 'Thank You',
  description: 'Thanks for getting in touch. We will be back to you within 24 hours.',
  robots: { index: false, follow: false },
};

export default function ThankYouPage() {
  return <ThankYouContent />;
}
