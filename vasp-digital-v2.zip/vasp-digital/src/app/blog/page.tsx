import type { Metadata } from 'next';
import BlogHero from '@/sections/blog/BlogHero';
import BlogGrid from '@/sections/blog/BlogGrid';

export const metadata: Metadata = {
  title: 'Blog — Digital Marketing Insights',
  description: 'Practical advice on SEO, local search, paid advertising, and web design for local businesses.',
};

export default function BlogPage() {
  return (
    <>
      <BlogHero />
      <BlogGrid />
    </>
  );
}
