import type { Metadata } from 'next';
import CTASection from '@/sections/shared/CTASection';
import BlogPostContent from '@/sections/blog/BlogPostContent';

interface Props { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  return {
    title: slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
    description: 'Read this article on VASP Digital — digital marketing insights for local businesses.',
  };
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;
  return (
    <>
      <BlogPostContent slug={slug} />
      <CTASection
        title="Ready to grow your business?"
        description="Book a free audit and let's talk about what's possible."
        variant="purple"
      />
    </>
  );
}
