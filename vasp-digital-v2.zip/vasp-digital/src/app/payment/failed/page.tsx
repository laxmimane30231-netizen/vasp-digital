import type { Metadata } from 'next';
import PaymentFailedContent from '@/sections/payment/PaymentFailedContent';

export const metadata: Metadata = {
  title: 'Payment Failed',
  description: 'There was an issue processing your payment.',
  robots: { index: false, follow: false },
};

export default function PaymentFailedPage() {
  return <PaymentFailedContent />;
}
