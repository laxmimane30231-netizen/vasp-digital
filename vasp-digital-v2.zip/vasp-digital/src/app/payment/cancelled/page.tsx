import type { Metadata } from 'next';
import PaymentCancelledContent from '@/sections/payment/PaymentCancelledContent';

export const metadata: Metadata = {
  title: 'Payment Cancelled',
  description: 'Your payment was cancelled. No charge was made.',
  robots: { index: false, follow: false },
};

export default function PaymentCancelledPage() {
  return <PaymentCancelledContent />;
}
