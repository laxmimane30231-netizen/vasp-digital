import type { Metadata } from 'next';
import PaymentSuccessContent from '@/sections/payment/PaymentSuccessContent';

export const metadata: Metadata = {
  title: 'Payment Successful',
  description: 'Your payment was successful. Welcome aboard!',
  robots: { index: false, follow: false },
};

export default function PaymentSuccessPage() {
  return <PaymentSuccessContent />;
}
