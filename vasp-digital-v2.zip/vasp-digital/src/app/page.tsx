import type { Metadata } from 'next';
import HeroSection from '@/sections/home/HeroSection';
import ServicesSection from '@/sections/home/ServicesSection';
import AboutSection from '@/sections/home/AboutSection';
import ResultsSection from '@/sections/home/ResultsSection';
import IndustriesSection from '@/sections/home/IndustriesSection';
import LocationsSection from '@/sections/home/LocationsSection';
import ProcessSection from '@/sections/home/ProcessSection';
import TestimonialsSection from '@/sections/home/TestimonialsSection';
import FAQSection from '@/sections/home/FAQSection';
import CTASection from '@/sections/shared/CTASection';

export const metadata: Metadata = {
  title: 'VASP Digital — Digital Marketing for Local Businesses',
  description: 'VASP Digital helps local and small businesses in London and the GTA get more leads through SEO, local search visibility, paid advertising, and better websites.',
};

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <ServicesSection />
      <AboutSection />
      <ResultsSection />
      <IndustriesSection />
      <LocationsSection />
      <ProcessSection />
      <TestimonialsSection />
      <FAQSection />
      <CTASection
        variant="coral"
        title="Let's talk growth"
        description="Tell us about your business. We'll listen and show you exactly how we can help."
        primaryCTA={{ label: 'Book a call', href: '/contact?type=call' }}
        secondaryCTA={{ label: 'Send a message', href: '/contact' }}
      />
    </>
  );
}
