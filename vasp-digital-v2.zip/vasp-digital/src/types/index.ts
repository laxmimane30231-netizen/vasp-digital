// ─── Core Data Types ──────────────────────────────────────────────────────────

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: unknown; // Payload rich text
  featuredImage?: MediaItem;
  author?: string;
  category: 'SEO' | 'Local SEO' | 'Paid Ads' | 'Web Design' | 'Strategy' | 'Case Study';
  tags?: string[];
  publishDate: string;
  status: 'draft' | 'published';
  seo?: SEOMeta;
}

export interface TeamMember {
  id: string;
  name: string;
  designation: string;
  bio?: string;
  image?: MediaItem;
  linkedin?: string;
  order?: number;
}

export interface CaseStudy {
  id: string;
  title: string;
  slug: string;
  client: string;
  industry?: string;
  location?: string;
  challenge?: unknown;
  solution?: unknown;
  results?: Array<{ metric: string; value: string }>;
  featuredImage?: MediaItem;
  gallery?: Array<{ image: MediaItem }>;
  services?: Array<{ service: string }>;
  publishDate?: string;
}

export interface Service {
  id: string;
  title: string;
  slug: string;
  description?: string;
  icon?: string;
  content?: unknown;
  featuredImage?: MediaItem;
  order?: number;
}

export interface Industry {
  id: string;
  title: string;
  slug: string;
  description?: string;
  content?: unknown;
  image?: MediaItem;
}

export interface Location {
  id: string;
  city: string;
  slug: string;
  province?: string;
  description?: string;
  content?: unknown;
  image?: MediaItem;
  seo?: SEOMeta;
}

export interface Testimonial {
  id: string;
  name: string;
  company?: string;
  role?: string;
  review: string;
  image?: MediaItem;
  rating?: number;
  featured?: boolean;
}

export interface ContactSubmission {
  name: string;
  email: string;
  phone?: string;
  company?: string;
  message: string;
  source?: string;
}

export interface MediaItem {
  id: string;
  url: string;
  alt: string;
  caption?: string;
  width?: number;
  height?: number;
  sizes?: {
    thumbnail?: { url: string; width: number; height: number };
    card?: { url: string; width: number; height: number };
    hero?: { url: string; width: number; height: number };
  };
}

export interface SEOMeta {
  metaTitle?: string;
  metaDescription?: string;
  ogImage?: MediaItem;
}

// ─── Component Prop Types ─────────────────────────────────────────────────────

export type ColorVariant = 'purple' | 'coral' | 'dark' | 'grey' | 'white';
export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'white';
export type ButtonSize = 'sm' | 'md' | 'lg';
