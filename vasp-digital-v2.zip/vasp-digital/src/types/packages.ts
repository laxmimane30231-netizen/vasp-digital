// ─── Currency & Geo ──────────────────────────────────────────────────────────

export type CurrencyCode = 'USD' | 'CAD' | 'GBP' | 'EUR' | 'AUD';

export interface Currency {
  code: CurrencyCode;
  symbol: string;
  label: string;
  stripeCurrency: string; // lowercase for Stripe
}

export const CURRENCIES: Record<CurrencyCode, Currency> = {
  USD: { code: 'USD', symbol: '$',   label: 'US Dollar',        stripeCurrency: 'usd' },
  CAD: { code: 'CAD', symbol: 'C$',  label: 'Canadian Dollar',  stripeCurrency: 'cad' },
  GBP: { code: 'GBP', symbol: '£',   label: 'British Pound',    stripeCurrency: 'gbp' },
  EUR: { code: 'EUR', symbol: '€',   label: 'Euro',             stripeCurrency: 'eur' },
  AUD: { code: 'AUD', symbol: 'A$',  label: 'Australian Dollar',stripeCurrency: 'aud' },
};

export const COUNTRY_CURRENCY_MAP: Record<string, CurrencyCode> = {
  US: 'USD', CA: 'CAD', GB: 'GBP', AU: 'AUD',
  DE: 'EUR', FR: 'EUR', IT: 'EUR', ES: 'EUR', NL: 'EUR',
  BE: 'EUR', AT: 'EUR', PT: 'EUR', IE: 'EUR', FI: 'EUR',
  GR: 'EUR', PL: 'EUR', SE: 'EUR', DK: 'EUR', NO: 'EUR',
  NZ: 'AUD', SG: 'USD', IN: 'USD', ZA: 'USD',
};

export const DEFAULT_CURRENCY: CurrencyCode = 'USD';

// ─── Package Types ────────────────────────────────────────────────────────────

export interface PackageFeature {
  text: string;
  included: boolean;
}

export interface CountryPrice {
  country: string;
  currency: CurrencyCode;
  price: number;
}

/** Matches the Payload CMS PackagesCollection shape */
export interface ServicePackage {
  id: string;
  title: string;
  slug: string;
  description: string;
  packageType: 'seo' | 'local-seo' | 'link-building' | 'paid-ads' | 'web-design';
  basePrice: number;
  baseCurrency: CurrencyCode;
  countryPricing: CountryPrice[];
  features: PackageFeature[];
  buttonText: string;
  isPopular: boolean;
  displayOrder: number;
  locationTargeting?: string[];
  stripeProductId?: string;
  stripePriceIds?: Record<CurrencyCode, string>; // pre-created Stripe Price IDs per currency
  billingPeriod: 'one-time' | 'monthly' | 'annual';
  status: 'active' | 'archived';
}

// ─── Stripe / Checkout ────────────────────────────────────────────────────────

export interface CheckoutSessionRequest {
  packageId: string;
  currency: CurrencyCode;
  customerEmail?: string;
  successUrl?: string;
  cancelUrl?: string;
  metadata?: Record<string, string>;
}

export interface CheckoutSessionResponse {
  sessionId: string;
  url: string;
}

export interface WebhookEvent {
  type: string;
  data: Record<string, unknown>;
}
