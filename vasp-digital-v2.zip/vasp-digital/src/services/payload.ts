/**
 * Payload CMS API Service
 * Fetches data from the Payload REST API.
 * Base URL: /api (relative, same-origin when self-hosted)
 * or https://your-payload-instance.com/api for external.
 */

const PAYLOAD_API_URL = process.env.NEXT_PUBLIC_PAYLOAD_URL ?? 'http://localhost:3001';

type FetchOptions = {
  depth?: number;
  limit?: number;
  page?: number;
  where?: Record<string, unknown>;
  sort?: string;
};

async function fetchPayload<T>(
  collection: string,
  options: FetchOptions = {},
  revalidate = 60
): Promise<{ docs: T[]; totalDocs: number; totalPages: number; page: number }> {
  const params = new URLSearchParams();
  if (options.depth)  params.set('depth', String(options.depth));
  if (options.limit)  params.set('limit', String(options.limit));
  if (options.page)   params.set('page', String(options.page));
  if (options.sort)   params.set('sort', options.sort);
  if (options.where)  params.set('where', JSON.stringify(options.where));

  const url = `${PAYLOAD_API_URL}/api/${collection}?${params.toString()}`;

  const res = await fetch(url, {
    next: { revalidate },
    headers: { 'Content-Type': 'application/json' },
  });

  if (!res.ok) throw new Error(`Payload fetch failed: ${collection} (${res.status})`);
  return res.json();
}

async function fetchPayloadDoc<T>(
  collection: string,
  slug: string,
  revalidate = 60
): Promise<T | null> {
  try {
    const result = await fetchPayload<T>(
      collection,
      { where: { slug: { equals: slug } }, depth: 2, limit: 1 },
      revalidate
    );
    return result.docs[0] ?? null;
  } catch {
    return null;
  }
}

// ─── Typed API Methods ─────────────────────────────────────────────────────

import type { BlogPost, TeamMember, CaseStudy, Testimonial, Service, Industry, Location } from '@/types';

export const PayloadAPI = {
  blog: {
    list: (opts?: FetchOptions) =>
      fetchPayload<BlogPost>('blog', {
        where: { status: { equals: 'published' } },
        sort: '-publishDate',
        depth: 1,
        ...opts,
      }),
    bySlug: (slug: string) => fetchPayloadDoc<BlogPost>('blog', slug),
  },

  team: {
    list: (opts?: FetchOptions) =>
      fetchPayload<TeamMember>('team', { sort: 'order', depth: 1, ...opts }),
  },

  caseStudies: {
    list: (opts?: FetchOptions) =>
      fetchPayload<CaseStudy>('case-studies', { sort: '-publishDate', depth: 1, ...opts }),
    bySlug: (slug: string) => fetchPayloadDoc<CaseStudy>('case-studies', slug),
  },

  testimonials: {
    featured: () =>
      fetchPayload<Testimonial>('testimonials', {
        where: { featured: { equals: true } },
        depth: 1,
        limit: 6,
      }),
    list: (opts?: FetchOptions) => fetchPayload<Testimonial>('testimonials', { depth: 1, ...opts }),
  },

  services: {
    list: (opts?: FetchOptions) =>
      fetchPayload<Service>('services', { sort: 'order', depth: 1, ...opts }),
    bySlug: (slug: string) => fetchPayloadDoc<Service>('services', slug),
  },

  industries: {
    list: (opts?: FetchOptions) =>
      fetchPayload<Industry>('industries', { depth: 1, ...opts }),
    bySlug: (slug: string) => fetchPayloadDoc<Industry>('industries', slug),
  },

  locations: {
    list: (opts?: FetchOptions) =>
      fetchPayload<Location>('locations', { sort: 'city', depth: 1, ...opts }),
    bySlug: (slug: string) => fetchPayloadDoc<Location>('locations', slug),
  },
};
