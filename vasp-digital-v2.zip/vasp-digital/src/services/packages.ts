/**
 * Packages Service
 * Fetches package data from Payload CMS REST API.
 * Falls back to static seed data when CMS is not connected.
 */

import type { ServicePackage, CurrencyCode } from '@/types/packages';

const PAYLOAD_URL = process.env.NEXT_PUBLIC_PAYLOAD_URL ?? 'http://localhost:3001';

// ─── Static seed data (used when CMS is offline) ─────────────────────────────
// This is the ONLY place pricing is hardcoded — purely as a dev fallback.
// Real production data comes from Payload CMS.

export const SEED_PACKAGES: ServicePackage[] = [
  // ── SEO PACKAGES ──────────────────────────────────────────────────────────
  {
    id: 'seo-starter',
    title: 'SEO Starter',
    slug: 'seo-starter',
    packageType: 'seo',
    description: 'Perfect for small businesses just getting started with SEO.',
    basePrice: 499,
    baseCurrency: 'CAD',
    billingPeriod: 'monthly',
    isPopular: false,
    displayOrder: 1,
    buttonText: 'Get started',
    status: 'active',
    countryPricing: [
      { country: 'US', currency: 'USD', price: 399 },
      { country: 'GB', currency: 'GBP', price: 319 },
      { country: 'AU', currency: 'AUD', price: 599 },
      { country: 'DE', currency: 'EUR', price: 369 },
    ],
    features: [
      { text: 'Up to 10 target keywords', included: true },
      { text: 'On-page SEO optimisation', included: true },
      { text: 'Monthly ranking report', included: true },
      { text: 'Technical SEO audit', included: true },
      { text: 'Link building', included: false },
      { text: 'Content creation', included: false },
    ],
    stripePriceIds: {} as Record<CurrencyCode, string>,
  },
  {
    id: 'seo-growth',
    title: 'SEO Growth',
    slug: 'seo-growth',
    packageType: 'seo',
    description: 'For growing businesses that need faster, more consistent results.',
    basePrice: 999,
    baseCurrency: 'CAD',
    billingPeriod: 'monthly',
    isPopular: true,
    displayOrder: 2,
    buttonText: 'Get started',
    status: 'active',
    countryPricing: [
      { country: 'US', currency: 'USD', price: 799 },
      { country: 'GB', currency: 'GBP', price: 629 },
      { country: 'AU', currency: 'AUD', price: 1199 },
      { country: 'DE', currency: 'EUR', price: 739 },
    ],
    features: [
      { text: 'Up to 25 target keywords', included: true },
      { text: 'On-page SEO optimisation', included: true },
      { text: 'Monthly ranking report', included: true },
      { text: 'Technical SEO audit', included: true },
      { text: '4 link building outreaches/mo', included: true },
      { text: '2 blog posts/month', included: true },
    ],
    stripePriceIds: {} as Record<CurrencyCode, string>,
  },
  {
    id: 'seo-authority',
    title: 'SEO Authority',
    slug: 'seo-authority',
    packageType: 'seo',
    description: 'Full-scale SEO for businesses serious about dominating search.',
    basePrice: 1799,
    baseCurrency: 'CAD',
    billingPeriod: 'monthly',
    isPopular: false,
    displayOrder: 3,
    buttonText: 'Get started',
    status: 'active',
    countryPricing: [
      { country: 'US', currency: 'USD', price: 1399 },
      { country: 'GB', currency: 'GBP', price: 1099 },
      { country: 'AU', currency: 'AUD', price: 2099 },
      { country: 'DE', currency: 'EUR', price: 1299 },
    ],
    features: [
      { text: 'Unlimited target keywords', included: true },
      { text: 'On-page SEO optimisation', included: true },
      { text: 'Weekly ranking report', included: true },
      { text: 'Advanced technical SEO', included: true },
      { text: '10 link building outreaches/mo', included: true },
      { text: '4 blog posts/month', included: true },
    ],
    stripePriceIds: {} as Record<CurrencyCode, string>,
  },
  // ── LOCAL SEO PACKAGES ─────────────────────────────────────────────────────
  {
    id: 'local-seo-essential',
    title: 'Local Essential',
    slug: 'local-seo-essential',
    packageType: 'local-seo',
    description: 'Get your Google Business Profile optimised and start ranking locally.',
    basePrice: 349,
    baseCurrency: 'CAD',
    billingPeriod: 'monthly',
    isPopular: false,
    displayOrder: 1,
    buttonText: 'Get started',
    status: 'active',
    countryPricing: [
      { country: 'US', currency: 'USD', price: 279 },
      { country: 'GB', currency: 'GBP', price: 219 },
      { country: 'AU', currency: 'AUD', price: 419 },
      { country: 'DE', currency: 'EUR', price: 259 },
    ],
    locationTargeting: [],
    features: [
      { text: 'Google Business Profile setup & optimisation', included: true },
      { text: 'Up to 3 local citations', included: true },
      { text: 'Review monitoring', included: true },
      { text: 'Monthly local rankings report', included: true },
      { text: 'Competitor analysis', included: false },
      { text: 'Local content creation', included: false },
    ],
    stripePriceIds: {} as Record<CurrencyCode, string>,
  },
  {
    id: 'local-seo-dominate',
    title: 'Local Dominate',
    slug: 'local-seo-dominate',
    packageType: 'local-seo',
    description: 'Full local SEO to rank #1 in Google Maps and local search.',
    basePrice: 699,
    baseCurrency: 'CAD',
    billingPeriod: 'monthly',
    isPopular: true,
    displayOrder: 2,
    buttonText: 'Get started',
    status: 'active',
    countryPricing: [
      { country: 'US', currency: 'USD', price: 549 },
      { country: 'GB', currency: 'GBP', price: 429 },
      { country: 'AU', currency: 'AUD', price: 829 },
      { country: 'DE', currency: 'EUR', price: 509 },
    ],
    locationTargeting: [],
    features: [
      { text: 'Full GBP management', included: true },
      { text: 'Up to 20 local citations', included: true },
      { text: 'Review generation strategy', included: true },
      { text: 'Weekly local rankings report', included: true },
      { text: 'Competitor analysis', included: true },
      { text: '2 local landing pages/month', included: true },
    ],
    stripePriceIds: {} as Record<CurrencyCode, string>,
  },
  // ── LINK BUILDING PACKAGES ─────────────────────────────────────────────────
  {
    id: 'links-starter',
    title: 'Link Starter',
    slug: 'links-starter',
    packageType: 'link-building',
    description: 'Start building domain authority with quality backlinks.',
    basePrice: 449,
    baseCurrency: 'CAD',
    billingPeriod: 'monthly',
    isPopular: false,
    displayOrder: 1,
    buttonText: 'Get started',
    status: 'active',
    countryPricing: [
      { country: 'US', currency: 'USD', price: 349 },
      { country: 'GB', currency: 'GBP', price: 279 },
      { country: 'AU', currency: 'AUD', price: 529 },
      { country: 'DE', currency: 'EUR', price: 329 },
    ],
    features: [
      { text: '5 quality backlinks per month', included: true },
      { text: 'DR 30+ domains', included: true },
      { text: 'Niche-relevant placements', included: true },
      { text: 'Monthly link report', included: true },
      { text: 'Guest post content included', included: false },
    ],
    stripePriceIds: {} as Record<CurrencyCode, string>,
  },
  {
    id: 'links-authority',
    title: 'Link Authority',
    slug: 'links-authority',
    packageType: 'link-building',
    description: 'Aggressive link building for competitive niches.',
    basePrice: 899,
    baseCurrency: 'CAD',
    billingPeriod: 'monthly',
    isPopular: true,
    displayOrder: 2,
    buttonText: 'Get started',
    status: 'active',
    countryPricing: [
      { country: 'US', currency: 'USD', price: 699 },
      { country: 'GB', currency: 'GBP', price: 549 },
      { country: 'AU', currency: 'AUD', price: 1049 },
      { country: 'DE', currency: 'EUR', price: 649 },
    ],
    features: [
      { text: '12 quality backlinks per month', included: true },
      { text: 'DR 50+ domains', included: true },
      { text: 'Niche-relevant placements', included: true },
      { text: 'Weekly link report', included: true },
      { text: 'Guest post content included', included: true },
    ],
    stripePriceIds: {} as Record<CurrencyCode, string>,
  },
];

// ─── Fetch from CMS ───────────────────────────────────────────────────────────

async function fetchPackagesFromCMS(type?: string): Promise<ServicePackage[]> {
  const where = {
    status: { equals: 'active' },
    ...(type ? { packageType: { equals: type } } : {}),
  };
  const params = new URLSearchParams({
    where: JSON.stringify(where),
    sort: 'displayOrder',
    limit: '50',
    depth: '0',
  });
  const res = await fetch(`${PAYLOAD_URL}/api/packages?${params}`, {
    next: { revalidate: 60 },
  });
  if (!res.ok) throw new Error(`Packages fetch failed: ${res.status}`);
  const data = await res.json();

  // Map CMS shape → ServicePackage
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (data.docs ?? []).map((doc: any): ServicePackage => ({
    id: doc.id,
    title: doc.title,
    slug: doc.slug,
    packageType: doc.packageType,
    description: doc.description,
    basePrice: doc.pricing?.basePrice ?? 0,
    baseCurrency: doc.pricing?.baseCurrency ?? 'CAD',
    countryPricing: (doc.pricing?.countryPricing ?? []).map((cp: { currency: CurrencyCode; price: number }) => ({
      country: '',
      currency: cp.currency,
      price: cp.price,
    })),
    features: doc.features ?? [],
    buttonText: doc.buttonText ?? 'Get started',
    isPopular: doc.isPopular ?? false,
    displayOrder: doc.displayOrder ?? 0,
    billingPeriod: doc.billingPeriod ?? 'monthly',
    status: doc.status ?? 'active',
    stripeProductId: doc.stripe?.productId,
    stripePriceIds: {
      USD: doc.stripe?.priceIdUSD,
      CAD: doc.stripe?.priceIdCAD,
      GBP: doc.stripe?.priceIdGBP,
      EUR: doc.stripe?.priceIdEUR,
      AUD: doc.stripe?.priceIdAUD,
    } as Record<CurrencyCode, string>,
    locationTargeting: (doc.locationTargeting ?? []).map((l: { location: string }) => l.location),
  }));
}

/**
 * Get packages by type, falling back to seed data if CMS is unavailable.
 */
export async function getPackages(type?: ServicePackage['packageType']): Promise<ServicePackage[]> {
  try {
    const pkgs = await fetchPackagesFromCMS(type);
    if (pkgs.length > 0) return pkgs;
    throw new Error('Empty response — using seed data');
  } catch {
    const seed = type ? SEED_PACKAGES.filter(p => p.packageType === type) : SEED_PACKAGES;
    return seed.filter(p => p.status === 'active').sort((a, b) => a.displayOrder - b.displayOrder);
  }
}
