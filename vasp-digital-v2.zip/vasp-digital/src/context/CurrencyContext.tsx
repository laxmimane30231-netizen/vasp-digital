'use client';

import { createContext, useContext, ReactNode } from 'react';
import { useCurrency } from '@/hooks/useCurrency';
import { CurrencyCode, Currency, CURRENCIES } from '@/types/packages';

interface CurrencyContextValue {
  currency: Currency;
  currencyCode: CurrencyCode;
  setCurrency: (code: CurrencyCode) => void;
  formatPrice: (amount: number) => string;
  isLoading: boolean;
}

const CurrencyContext = createContext<CurrencyContextValue>({
  currency: CURRENCIES['USD'],
  currencyCode: 'USD',
  setCurrency: () => {},
  formatPrice: (n) => `$${n}`,
  isLoading: false,
});

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const value = useCurrency();
  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>;
}

export function useCurrencyContext() {
  return useContext(CurrencyContext);
}
