'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

const locations = [
  { slug: 'london', city: 'London', province: 'Ontario', description: 'SEO and local search for southwestern Ontario businesses.' },
  { slug: 'toronto', city: 'Toronto', province: 'Ontario', description: 'Dominate search in Canada\'s largest market.' },
  { slug: 'mississauga', city: 'Mississauga', province: 'Ontario', description: 'Digital marketing for Mississauga businesses.' },
  { slug: 'hamilton', city: 'Hamilton', province: 'Ontario', description: 'Local SEO and paid ads for Hamilton businesses.' },
  { slug: 'brampton', city: 'Brampton', province: 'Ontario', description: 'Growing businesses across Brampton.' },
  { slug: 'oakville', city: 'Oakville', province: 'Ontario', description: 'Premium digital marketing for Oakville businesses.' },
];

export default function LocationsGrid() {
  return (
    <section className="bg-white py-16 lg:py-20">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {locations.map((loc, i) => (
            <motion.div
              key={loc.slug}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08, ease: 'easeOut' }}
              className="group"
            >
              <div className="rounded-2xl overflow-hidden bg-[#e3dbff] aspect-[16/9] mb-4 flex items-center justify-center group-hover:shadow-md transition-shadow">
                <span className="text-[#623ccc]/30 text-sm">{loc.city}</span>
              </div>
              <div className="text-xs text-black/40 mb-1">{loc.province}</div>
              <h3 className="text-lg font-bold mb-1">{loc.city}</h3>
              <p className="text-black/60 text-sm mb-3">{loc.description}</p>
              <Link href={`/locations/${loc.slug}`} className="inline-flex items-center gap-1.5 text-sm font-semibold hover:text-[#623ccc] transition-colors">
                Explore <ArrowRight size={14} />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
