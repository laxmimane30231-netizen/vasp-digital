'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

const services = [
  {
    number: '01',
    label: 'Organic search',
    title: 'SEO',
    headline: 'Rank higher and own your search results',
    description: 'We build SEO strategies that put your business in front of people actively searching for what you offer. Steady, sustainable growth that compounds over time.',
    exploreHref: '/services/seo',
    learnHref: '/services/seo#learn',
    imagePlaceholder: 'Man at laptop',
    imageAlt: 'SEO strategy',
  },
  {
    number: '02',
    label: 'Local visibility',
    title: 'Local SEO',
    headline: 'Get found when customers search near you',
    description: 'Dominate local search results and Google Maps. We optimize your profile, citations, and local signals so customers in your area find you first.',
    exploreHref: '/services/local-seo',
    learnHref: '/services/local-seo#learn',
    imagePlaceholder: 'Person on phone outside',
    imageAlt: 'Local SEO',
  },
  {
    number: '03',
    label: 'Paid advertising',
    title: 'Paid Ads',
    headline: 'Drive qualified leads with Google and Meta ads',
    description: 'Fast results when you need them. We run Google Ads and Meta campaigns that target the right people at the right time, turning clicks into customers.',
    exploreHref: '/services/paid-ads',
    learnHref: '/services/paid-ads#learn',
    imagePlaceholder: 'Team working together',
    imageAlt: 'Paid ads',
  },
];

export default function ServicesSection() {
  return (
    <section className="bg-white">
      {services.map((service, i) => (
        <div key={service.number} className="border-t border-black/10">
          <div className="container py-5">
            <div className="flex items-center gap-3 text-black/40">
              <span className="text-xs font-semibold">{service.number}</span>
              <span className="text-xs">{service.label}</span>
            </div>
          </div>

          <div className="container pb-16 lg:pb-20">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-20 items-center">
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.6, ease: 'easeOut' }}
              >
                <SectionLabel className="mb-3 text-[#623ccc]">{service.title}</SectionLabel>
                <h2 className="text-[32px] md:text-[40px] lg:text-[44px] font-bold leading-tight tracking-tight mb-4">
                  {service.headline}
                </h2>
                <p className="text-black/60 text-base leading-relaxed mb-6 max-w-md">
                  {service.description}
                </p>
                <div className="flex items-center gap-4">
                  <Link href={service.exploreHref} className="inline-flex items-center gap-2 px-5 py-2.5 border border-black/20 rounded-full text-sm font-semibold hover:border-black hover:bg-black/5 transition-colors">
                    Explore
                  </Link>
                  <Link href={service.learnHref} className="inline-flex items-center gap-1.5 text-sm font-semibold text-black/70 hover:text-black transition-colors">
                    Learn <ArrowRight size={14} />
                  </Link>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.6, delay: 0.1, ease: 'easeOut' }}
                className={`rounded-2xl overflow-hidden aspect-[4/3] bg-[#f1f1f1] ${i % 2 === 0 ? 'lg:order-last' : 'lg:order-first'}`}
              >
                <div className="w-full h-full flex items-center justify-center text-black/20 text-sm">
                  {service.imagePlaceholder}
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      ))}
    </section>
  );
}
