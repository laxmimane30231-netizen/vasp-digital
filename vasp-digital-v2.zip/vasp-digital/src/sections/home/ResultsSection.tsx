'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

const results = [
  {
    tag: 'Leads',
    title: 'Higher search rankings',
    description: 'Clients find you when they\'re searching',
    href: '/services/seo',
    image: 'People at work',
  },
  {
    tag: 'Traffic',
    title: 'Better conversion rates',
    description: 'Websites that turn visitors into paying clients',
    href: '/services/web-design',
    image: 'Team meeting outdoors',
  },
  {
    tag: 'Growth',
    title: 'Faster results with paid advertising',
    description: 'Google and Meta ads that work hard for you',
    href: '/services/paid-ads',
    image: 'Person on laptop outside',
  },
];

export default function ResultsSection() {
  return (
    <section className="bg-white py-16 lg:py-24 border-t border-black/10">
      <div className="container">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <SectionLabel className="mb-3">Results</SectionLabel>
          <h2 className="text-[32px] md:text-[40px] lg:text-[44px] font-bold leading-tight tracking-tight mb-3">
            Real growth, real numbers
          </h2>
          <p className="text-black/50 text-base">More leads from Google search and maps</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {results.map((item, i) => (
            <motion.div
              key={item.tag}
              className="group"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
            >
              <div className="rounded-2xl overflow-hidden bg-[#f1f1f1] aspect-[4/3] mb-4 group-hover:shadow-md transition-shadow">
                <div className="w-full h-full flex items-center justify-center text-black/20 text-sm">
                  {item.image}
                </div>
              </div>
              <SectionLabel className="mb-1.5 text-[#623ccc]">{item.tag}</SectionLabel>
              <h3 className="text-lg font-bold mb-1.5">{item.title}</h3>
              <p className="text-black/60 text-sm mb-3">{item.description}</p>
              <Link
                href={item.href}
                className="inline-flex items-center gap-1.5 text-sm font-semibold hover:text-[#623ccc] transition-colors"
              >
                Learn <ArrowRight size={14} />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
