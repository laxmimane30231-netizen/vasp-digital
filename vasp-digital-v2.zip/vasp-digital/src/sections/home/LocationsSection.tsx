'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

const locations = [
  {
    city: 'London',
    label: 'London businesses',
    description: 'SEO and local search for southwestern Ontario',
    href: '/locations/london',
    image: 'London city',
  },
  {
    city: 'Toronto',
    label: 'Greater Toronto Area',
    description: 'Dominate search in Canada\'s largest market',
    href: '/locations/toronto',
    image: 'Toronto skyline',
  },
  {
    city: 'Ontario',
    label: 'Expanding across the province',
    description: 'Growing businesses statewide with proven strategies',
    href: '/locations',
    image: 'Ontario landscape',
    wide: true,
  },
];

export default function LocationsSection() {
  return (
    <section className="bg-[#f0ecff] py-16 lg:py-24">
      <div className="container">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <SectionLabel className="mb-3">Coverage</SectionLabel>
          <h2 className="text-[32px] md:text-[40px] lg:text-[44px] font-bold leading-tight tracking-tight mb-3">
            Where we serve
          </h2>
          <p className="text-black/50 text-base">Helping businesses grow across Ontario and beyond</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {locations.map((loc, i) => (
            <motion.div
              key={loc.city}
              className={`group ${loc.wide ? 'md:col-span-1' : ''}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
            >
              <div className="rounded-2xl overflow-hidden bg-[#e3dbff] aspect-[4/3] mb-4 group-hover:shadow-md transition-shadow">
                <div className="w-full h-full flex items-center justify-center text-[#623ccc]/30 text-sm">
                  {loc.image}
                </div>
              </div>
              <SectionLabel className="mb-1.5">{loc.city}</SectionLabel>
              <h3 className="text-lg font-bold mb-1.5">{loc.label}</h3>
              <p className="text-black/60 text-sm mb-3">{loc.description}</p>
              <Link
                href={loc.href}
                className="inline-flex items-center gap-1.5 text-sm font-semibold hover:text-[#623ccc] transition-colors"
              >
                Explore <ArrowRight size={14} />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
