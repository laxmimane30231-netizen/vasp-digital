'use client';

import { motion } from 'framer-motion';
import Button from '@/components/ui/Button';

export default function HeroSection() {
  return (
    <section className="bg-[#623ccc] text-white pt-16 overflow-hidden">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center min-h-[580px] lg:min-h-[640px] py-16 lg:py-20">
          {/* Left: Content */}
          <div>
            <motion.h1
              className="text-[44px] md:text-[52px] lg:text-[64px] xl:text-[72px] font-bold leading-[1.05] tracking-tight mb-6"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
            >
              Grow your<br />
              business with<br />
              proven digital<br />
              strategies
            </motion.h1>

            <motion.p
              className="text-white/80 text-base lg:text-lg leading-relaxed mb-8 max-w-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.15, ease: "easeOut" }}
            >
              VASP Digital helps local and small businesses in London and the GTA get more leads through SEO, local search visibility, paid advertising, and better websites. We focus on what matters: your growth.
            </motion.p>

            <motion.div
              className="flex flex-wrap items-center gap-3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
            >
              <Button variant="white" size="md" href="/contact?type=call">
                Book a call
              </Button>
              <Button
                variant="ghost"
                size="md"
                href="/contact?type=audit"
                className="text-white hover:bg-white/10"
              >
                Free audit
              </Button>
            </motion.div>
          </div>

          {/* Right: Hero Image Placeholder */}
          <motion.div
            className="relative hidden lg:block"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          >
            <div className="relative rounded-2xl overflow-hidden aspect-[4/3] bg-white/10">
              <div className="w-full h-full bg-gradient-to-br from-purple-400/20 to-purple-900/30 flex items-center justify-center">
                <div className="text-white/20 text-sm font-medium">Team photo</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
