'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Search, Wrench, Scale, ArrowRight } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

const industries = [
  {
    icon: Search,
    title: 'Clinics and healthcare practices',
    description: 'Patients find you through local search and Google Ads.',
    href: '/industries/clinics',
  },
  {
    icon: Wrench,
    title: 'Contractors and trades',
    description: 'Rank for service calls in your area and get qualified leads.',
    href: '/industries/contractors',
  },
  {
    icon: Scale,
    title: 'Legal, real estate, and professional services',
    description: 'Build authority and attract high-value clients consistently.',
    href: '/industries/legal',
  },
];

export default function IndustriesSection() {
  return (
    <section className="bg-[#fd7056] py-16 lg:py-24 text-white">
      <div className="container">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <SectionLabel light className="mb-3">Industries</SectionLabel>
          <h2 className="text-[32px] md:text-[40px] lg:text-[44px] font-bold leading-tight tracking-tight mb-3">
            We work with businesses across every sector
          </h2>
          <p className="text-white/80 text-base max-w-2xl mx-auto">
            From clinics to contractors, legal firms to real estate. If you need more leads and better visibility, we&apos;ve helped businesses like yours.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {industries.map((industry, i) => {
            const Icon = industry.icon;
            return (
              <motion.div
                key={industry.title}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center mx-auto mb-4">
                  <Icon size={20} className="text-white" />
                </div>
                <h3 className="text-lg font-bold mb-2">{industry.title}</h3>
                <p className="text-white/70 text-sm leading-relaxed">{industry.description}</p>
              </motion.div>
            );
          })}
        </div>

        <div className="flex items-center justify-center gap-4">
          <Link
            href="/industries"
            className="px-6 py-3 bg-white text-black text-sm font-semibold rounded-full hover:bg-[#f0ecff] transition-colors"
          >
            Explore
          </Link>
          <Link
            href="/industries"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-white/80 hover:text-white transition-colors"
          >
            More <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </section>
  );
}
