'use client';

import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';

const steps = [
  {
    step: 'Discovery',
    title: 'We learn your business and market',
    description: 'Understand your goals and competition.',
    status: 'Next',
    image: 'Discovery meeting',
  },
  {
    step: 'Strategy',
    title: 'We build a plan built on data',
    description: 'SEO, ads, website, or all three.',
    status: 'Next',
    image: 'Strategy session',
  },
  {
    step: 'Launch',
    title: 'We execute and optimize constantly',
    description: 'Real work starts here, real results follow.',
    status: 'Next',
    image: 'Launch day',
  },
  {
    step: 'Grow',
    title: 'We measure, report, and scale what works',
    description: 'More leads, better rankings, stronger business.',
    status: 'Done',
    image: 'Growth results',
  },
];

export default function ProcessSection() {
  return (
    <section className="bg-white py-16 lg:py-24 border-t border-black/10">
      <div className="container">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <SectionLabel className="mb-3">Process</SectionLabel>
          <h2 className="text-[32px] md:text-[40px] lg:text-[44px] font-bold leading-tight tracking-tight mb-3">
            How we build your growth
          </h2>
          <p className="text-black/50 text-base max-w-xl mx-auto">
            We start with what you need, build a plan that works, and keep pushing for better results every month.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, i) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
            >
              <SectionLabel className="mb-2 text-[#623ccc]">{step.step}</SectionLabel>
              <h3 className="text-base font-bold mb-1.5 leading-tight">{step.title}</h3>
              <p className="text-black/60 text-sm mb-4">{step.description}</p>
              <div className="flex items-center gap-1.5 text-xs font-semibold text-black/40">
                <span>{step.status}</span>
                {step.status === 'Next' && (
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                )}
                {step.status === 'Done' && (
                  <svg className="w-3 h-3 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </div>
              <div className="mt-4 rounded-xl overflow-hidden bg-[#f1f1f1] aspect-[4/3]">
                <div className="w-full h-full flex items-center justify-center text-black/20 text-xs">
                  {step.image}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
