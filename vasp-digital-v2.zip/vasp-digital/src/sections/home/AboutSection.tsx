'use client';

import { motion } from 'framer-motion';

export default function AboutSection() {
  return (
    <section className="bg-[#f0ecff] py-16 lg:py-24">
      <div className="container">
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <div>
            <h2 className="text-[32px] md:text-[40px] lg:text-[44px] font-bold leading-tight tracking-tight">
              Built for local business growth
            </h2>
          </div>

          <div className="space-y-6">
            <p className="text-black/70 text-base leading-relaxed">
              We&apos;re not a generic agency. We&apos;ve spent years helping London and GTA businesses cut through the noise and get real leads from Google. That focus shows in everything we do.
            </p>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-base mb-2">Proven locally</h4>
                <p className="text-black/60 text-sm leading-relaxed">We know your market, your competitors, and what actually works here.</p>
              </div>
              <div>
                <h4 className="font-bold text-base mb-2">Results matter</h4>
                <p className="text-black/60 text-sm leading-relaxed">Every strategy we build is measured by leads, calls, and revenue growth.</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Video/Image placeholder */}
        <motion.div
          className="mt-12 rounded-2xl overflow-hidden bg-black aspect-video flex items-center justify-center"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, delay: 0.1, ease: "easeOut" }}
        >
          <button className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
            <svg className="w-6 h-6 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
        </motion.div>
      </div>
    </section>
  );
}
