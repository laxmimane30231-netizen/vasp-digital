'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import Link from 'next/link';
import SectionLabel from '@/components/ui/SectionLabel';

const faqs = [
  {
    question: 'How long until we see results?',
    answer: 'SEO takes time. Expect three to six months for real traction. Paid ads work faster, often within weeks. We\'re honest about timelines because we know what matters to you.',
  },
  {
    question: 'What if we\'re not ready for everything?',
    answer: 'Start with what makes sense. SEO, local search, ads, or a new website. We build a plan that fits your budget and goals. You can add more later.',
  },
  {
    question: 'Do you work with small budgets?',
    answer: 'Yes. We\'ve helped businesses with modest budgets get real leads. We focus on ROI, not spending big. If it doesn\'t work, we adjust.',
  },
  {
    question: 'Will you lock us into a long contract?',
    answer: 'No long-term contracts. We work month to month. If we\'re delivering, you stay. If not, you leave. That\'s how we stay sharp.',
  },
  {
    question: 'How do you measure success?',
    answer: 'We track leads, calls, and revenue growth — not just rankings and traffic. Every month you\'ll know exactly what\'s working and what we\'re improving.',
  },
];

function FAQItem({ question, answer, isOpen, onClick }: {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}) {
  return (
    <div className="border-b border-black/10 last:border-0">
      <button
        className="w-full flex items-start justify-between gap-4 py-5 text-left"
        onClick={onClick}
      >
        <span className="text-base font-semibold leading-snug">{question}</span>
        <ChevronDown
          size={18}
          className={`shrink-0 mt-0.5 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <p className="text-black/60 text-sm leading-relaxed pb-5">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FAQSection() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="bg-white py-16 lg:py-24 border-t border-black/10">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          <div>
            <SectionLabel className="mb-3">Questions</SectionLabel>
            <h2 className="text-[32px] md:text-[40px] font-bold leading-tight tracking-tight mb-4">
              Everything you need to know about working with VASP Digital
            </h2>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-5 py-2.5 border border-black/20 rounded-full text-sm font-semibold hover:border-black hover:bg-black/5 transition-colors"
            >
              Contact us
            </Link>
          </div>

          <div>
            {faqs.map((faq, i) => (
              <FAQItem
                key={i}
                question={faq.question}
                answer={faq.answer}
                isOpen={open === i}
                onClick={() => setOpen(open === i ? null : i)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
