'use client';

import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';

const testimonials = [
  {
    quote: 'We went from almost no online presence to getting calls every week. VASP Digital knew exactly what to do.',
    name: 'Sarah Mitchell',
    role: 'Owner, dental clinic',
  },
  {
    quote: 'They didn\'t just promise results. They delivered them. Our leads doubled in six months.',
    name: 'James Chen',
    role: 'Contractor, home services',
  },
  {
    quote: 'Finally, someone who understands local business. No jargon, just real growth.',
    name: 'Rebecca Walsh',
    role: 'Partner, legal firm',
  },
];

export default function TestimonialsSection() {
  return (
    <section className="bg-[#f0ecff] py-16 lg:py-24">
      <div className="container">
        <motion.div
          className="mb-10"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <SectionLabel className="mb-3">Real results</SectionLabel>
          <h2 className="text-[32px] md:text-[40px] lg:text-[44px] font-bold leading-tight tracking-tight">
            Hear from businesses we&apos;ve helped grow
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              className="bg-white rounded-2xl p-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
            >
              <blockquote className="text-base font-medium leading-relaxed mb-6 text-black">
                &ldquo;{t.quote}&rdquo;
              </blockquote>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#e3dbff] flex items-center justify-center text-[#623ccc] font-bold text-sm">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-semibold">{t.name}</div>
                  <div className="text-xs text-black/50">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
