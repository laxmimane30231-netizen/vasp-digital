'use client';
import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';

export default function CaseStudiesHero() {
  return (
    <section className="bg-black text-white pt-16">
      <div className="container py-16 lg:py-24">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="max-w-3xl"
        >
          <SectionLabel light className="mb-4">Case Studies</SectionLabel>
          <h1 className="text-[44px] md:text-[56px] font-bold leading-tight tracking-tight mb-4">
            Real growth, real numbers
          </h1>
          <p className="text-white/70 text-base lg:text-lg max-w-xl">
            See how we have helped local businesses get more leads, better rankings, and stronger revenue.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
