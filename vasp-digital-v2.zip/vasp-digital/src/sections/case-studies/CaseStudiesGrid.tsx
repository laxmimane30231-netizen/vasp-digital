'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

const caseStudies = [
  { slug: 'dental-clinic-london', client: 'Dental Clinic', location: 'London, ON', headline: '3x more calls in 90 days through local SEO', tags: ['Local SEO', 'GBP'], result: '+320% calls', bg: '#f0ecff' },
  { slug: 'contractor-gta', client: 'General Contractor', location: 'GTA', headline: 'From zero to page one: contractor dominates local search', tags: ['SEO', 'Google Ads'], result: '+180% leads', bg: '#e3dbff' },
  { slug: 'law-firm-mississauga', client: 'Law Firm', location: 'Mississauga', headline: 'New website + paid ads doubles client inquiries', tags: ['Web Design', 'Paid Ads'], result: '+210% inquiries', bg: '#f1f1f1' },
];

export default function CaseStudiesGrid() {
  return (
    <section className="bg-white py-16 lg:py-24">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {caseStudies.map((cs, i) => (
            <motion.div
              key={cs.slug}
              className="group rounded-2xl overflow-hidden border border-black/10 hover:shadow-md transition-shadow"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1, ease: 'easeOut' }}
            >
              <div className="aspect-[16/9] flex items-center justify-center" style={{ background: cs.bg }}>
                <span className="text-[48px] font-black text-black/10">{cs.result}</span>
              </div>
              <div className="p-6">
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {cs.tags.map(t => (
                    <span key={t} className="text-[10px] font-semibold uppercase tracking-wider bg-[#f0ecff] text-[#623ccc] px-2 py-0.5 rounded-full">{t}</span>
                  ))}
                </div>
                <div className="text-xs text-black/40 mb-1">{cs.client} · {cs.location}</div>
                <h3 className="text-base font-bold leading-snug mb-4">{cs.headline}</h3>
                <Link href={`/case-studies/${cs.slug}`} className="inline-flex items-center gap-1.5 text-sm font-semibold hover:text-[#623ccc] transition-colors">
                  Read case study <ArrowRight size={14} />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
