'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

export default function CaseStudyContent({ slug }: { slug: string }) {
  return (
    <>
      <section className="bg-black text-white pt-16">
        <div className="container py-12 lg:py-20">
          <Link href="/case-studies" className="inline-flex items-center gap-1.5 text-sm font-medium text-white/60 hover:text-white transition-colors mb-8">
            <ArrowLeft size={14} /> All case studies
          </Link>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: 'easeOut' }} className="max-w-3xl">
            <SectionLabel light className="mb-3">Dental Clinic · London, ON</SectionLabel>
            <h1 className="text-[36px] md:text-[52px] font-bold leading-tight tracking-tight mb-6">
              3x more calls in 90 days through local SEO
            </h1>
            <div className="grid grid-cols-3 gap-6 mt-8">
              {[['+320%', 'Phone calls'], ['#1', 'Google Maps rank'], ['90 days', 'To results']].map(([val, label]) => (
                <div key={label}>
                  <div className="text-3xl font-black text-[#623ccc] mb-1">{val}</div>
                  <div className="text-white/60 text-sm">{label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <section className="bg-white py-12 lg:py-16">
        <div className="container">
          <div className="max-w-2xl mx-auto space-y-8">
            {[
              { heading: 'The challenge', body: 'This dental clinic had been open for three years but was virtually invisible on Google Maps. Competitors with inferior reviews were ranking above them purely due to better optimization.' },
              { heading: 'What we did', body: 'We audited and rebuilt their Google Business Profile, corrected inconsistent citation data across 40+ directories, launched a review generation campaign, and created locally-optimized service pages on their website.' },
              { heading: 'The results', body: 'Within 90 days, the practice moved from position 8 to position 1 in Google Maps for their primary keyword. Phone calls through Google tripled, and they had to hire an additional front-desk staff member to handle the volume.' },
            ].map(section => (
              <div key={section.heading}>
                <h2 className="text-xl font-bold mb-3">{section.heading}</h2>
                <p className="text-black/60 text-base leading-relaxed">{section.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
