'use client';

import { motion } from 'framer-motion';
import PricingCard from '@/components/ui/PricingCard';
import CurrencySelector from '@/components/ui/CurrencySelector';
import SectionLabel from '@/components/ui/SectionLabel';
import type { ServicePackage } from '@/types/packages';

interface PricingSectionProps {
  label?: string;
  title: string;
  description?: string;
  packages: ServicePackage[];
  bgColor?: string;
}

export default function PricingSection({
  label = 'Pricing',
  title,
  description,
  packages,
  bgColor = 'bg-[#f0ecff]',
}: PricingSectionProps) {
  if (!packages.length) return null;

  return (
    <section className={`${bgColor} py-16 lg:py-24`}>
      <div className="container">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        >
          <div>
            <SectionLabel className="mb-2">{label}</SectionLabel>
            <h2 className="text-[28px] md:text-[36px] lg:text-[44px] font-bold leading-tight tracking-tight mb-2">
              {title}
            </h2>
            {description && (
              <p className="text-black/55 text-base leading-relaxed max-w-xl">{description}</p>
            )}
          </div>
          {/* Currency selector — top right */}
          <div className="shrink-0">
            <CurrencySelector />
          </div>
        </motion.div>

        {/* Cards grid */}
        <div className={`grid grid-cols-1 gap-6 ${
          packages.length === 2 ? 'md:grid-cols-2 max-w-3xl mx-auto' :
          packages.length >= 3 ? 'md:grid-cols-3' : ''
        }`}>
          {packages.map((pkg) => (
            <PricingCard key={pkg.id} pkg={pkg} />
          ))}
        </div>

        {/* Fine print */}
        <p className="text-center text-xs text-black/35 mt-8">
          All prices shown in your local currency. Secure checkout powered by Stripe.
          Cancel anytime for monthly plans.
        </p>
      </div>
    </section>
  );
}
