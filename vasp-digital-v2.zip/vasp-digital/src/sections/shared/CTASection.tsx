'use client';

import { motion } from 'framer-motion';
import Button from '@/components/ui/Button';

interface CTASectionProps {
  title?: string;
  description?: string;
  primaryCTA?: { label: string; href: string };
  secondaryCTA?: { label: string; href: string };
  variant?: 'purple' | 'black' | 'coral';
}

export default function CTASection({
  title = "Ready to grow your business?",
  description = "Book a call and let's talk about what's possible for your business.",
  primaryCTA = { label: 'Book a call', href: '/contact?type=call' },
  secondaryCTA = { label: 'Free audit', href: '/contact?type=audit' },
  variant = 'purple',
}: CTASectionProps) {
  const bgMap = {
    purple: 'bg-[#623ccc] text-white',
    black: 'bg-black text-white',
    coral: 'bg-[#fd7056] text-white',
  };

  return (
    <section className={`${bgMap[variant]} py-16 lg:py-24`}>
      <div className="container text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-[32px] md:text-[40px] lg:text-[52px] font-bold leading-tight tracking-tight mb-4">
            {title}
          </h2>
          <p className="text-white/70 text-base lg:text-lg max-w-xl mx-auto mb-8">
            {description}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Button variant="white" size="lg" href={primaryCTA.href}>
              {primaryCTA.label}
            </Button>
            <Button
              variant="ghost"
              size="lg"
              href={secondaryCTA.href}
              className="text-white hover:bg-white/10"
            >
              {secondaryCTA.label}
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
