'use client';
import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';

export default function AboutHero() {
  return (
    <section className="bg-black text-white pt-16">
      <div className="container py-20 lg:py-28">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="max-w-3xl"
        >
          <SectionLabel light className="mb-4">About VASP Digital</SectionLabel>
          <h1 className="text-[44px] md:text-[56px] lg:text-[72px] font-bold leading-tight tracking-tight mb-6">
            We grow local businesses the right way
          </h1>
          <p className="text-white/70 text-base lg:text-lg leading-relaxed max-w-2xl">
            VASP Digital was built around one idea: local businesses deserve the same quality of digital marketing that big companies get. We are a focused team working with clinics, contractors, legal firms, and service businesses across London and the GTA.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
