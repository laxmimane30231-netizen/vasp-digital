'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

export default function AboutTeamPreview() {
  return (
    <section className="bg-white py-16 lg:py-24 border-t border-black/10">
      <div className="container">
        <div className="flex items-end justify-between mb-10">
          <div>
            <SectionLabel className="mb-2">Team</SectionLabel>
            <h2 className="text-[28px] md:text-[36px] font-bold leading-tight tracking-tight">
              The people behind your growth
            </h2>
          </div>
          <Link href="/team" className="hidden md:inline-flex items-center gap-1.5 text-sm font-semibold hover:text-[#623ccc] transition-colors">
            Meet the team <ArrowRight size={14} />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
          {['Strategy Lead', 'SEO Specialist', 'Paid Ads Manager', 'Web Developer'].map((role, i) => (
            <motion.div
              key={role}
              className="group"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08, ease: 'easeOut' }}
            >
              <div className="rounded-2xl overflow-hidden aspect-square bg-[#e3dbff] mb-3 group-hover:shadow-sm transition-shadow flex items-center justify-center">
                <span className="text-[#623ccc]/30 text-xs">Photo</span>
              </div>
              <div className="text-sm font-semibold">Team Member</div>
              <div className="text-xs text-black/50">{role}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
