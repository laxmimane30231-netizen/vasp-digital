'use client';
import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';

const values = [
  { title: 'Local first', description: 'We know these markets because we work in them every day. No generic playbooks — just strategies built for your city.' },
  { title: 'Honest about results', description: 'We track leads, calls, and revenue. Not just rankings. We tell you what is working and what is not.' },
  { title: 'No long-term lock-ins', description: 'Month-to-month because we know we have to keep earning your business. If we stop delivering, you can leave.' },
  { title: 'Small team, big focus', description: 'You work with the people actually doing the work. No account managers in the middle, no outsourcing.' },
];

export default function AboutValues() {
  return (
    <section className="bg-[#f0ecff] py-16 lg:py-24">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="mb-12"
        >
          <SectionLabel className="mb-3">What we believe</SectionLabel>
          <h2 className="text-[28px] md:text-[36px] lg:text-[44px] font-bold leading-tight tracking-tight">
            How we think about our work
          </h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {values.map((v, i) => (
            <motion.div
              key={v.title}
              className="bg-white rounded-2xl p-8"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08, ease: 'easeOut' }}
            >
              <h3 className="text-lg font-bold mb-3">{v.title}</h3>
              <p className="text-black/60 text-sm leading-relaxed">{v.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
