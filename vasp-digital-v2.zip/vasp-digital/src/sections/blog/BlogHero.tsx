'use client';
import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';

export default function BlogHero() {
  return (
    <section className="bg-[#f0ecff] pt-16">
      <div className="container py-16 lg:py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        >
          <SectionLabel className="mb-3">Blog</SectionLabel>
          <h1 className="text-[36px] md:text-[48px] font-bold leading-tight tracking-tight mb-3">
            Digital marketing insights
          </h1>
          <p className="text-black/60 text-base max-w-lg">
            Practical advice on SEO, local search, paid advertising, and web design for local businesses.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
