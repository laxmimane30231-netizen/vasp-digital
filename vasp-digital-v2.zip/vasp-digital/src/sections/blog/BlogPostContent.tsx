'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowLeft, Clock, Calendar } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

interface BlogPostContentProps { slug: string }

export default function BlogPostContent({ slug }: BlogPostContentProps) {
  const title = slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  return (
    <>
      {/* Hero */}
      <section className="bg-[#f0ecff] pt-16">
        <div className="container py-12 lg:py-16">
          <Link href="/blog" className="inline-flex items-center gap-1.5 text-sm font-medium text-black/60 hover:text-black transition-colors mb-8">
            <ArrowLeft size={14} /> Back to blog
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="max-w-3xl"
          >
            <SectionLabel className="mb-3 text-[#623ccc]">Local SEO</SectionLabel>
            <h1 className="text-[32px] md:text-[44px] font-bold leading-tight tracking-tight mb-4">{title}</h1>
            <div className="flex items-center gap-5 text-sm text-black/50">
              <span className="flex items-center gap-1.5"><Calendar size={14} /> March 12, 2024</span>
              <span className="flex items-center gap-1.5"><Clock size={14} /> 8 min read</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Cover image */}
      <div className="bg-[#f1f1f1] aspect-[16/6] flex items-center justify-center">
        <span className="text-black/20 text-sm">Article cover image</span>
      </div>

      {/* Content */}
      <section className="bg-white py-12 lg:py-16">
        <div className="container">
          <div className="max-w-2xl mx-auto prose prose-lg prose-headings:font-bold prose-headings:tracking-tight">
            <p className="text-base text-black/70 leading-relaxed mb-6">
              Google Maps is where local customers decide who to call. Ranking in the local pack — the three business listings that appear at the top of local search results — can transform a local business.
            </p>
            <h2 className="text-2xl font-bold mt-8 mb-4">Why Google Maps rankings matter</h2>
            <p className="text-base text-black/70 leading-relaxed mb-6">
              Studies show that more than 80% of local searches result in a store visit or phone call within 24 hours. The businesses in the top three local pack positions capture the vast majority of that intent.
            </p>
            <h2 className="text-2xl font-bold mt-8 mb-4">The three core ranking factors</h2>
            <p className="text-base text-black/70 leading-relaxed mb-4">
              Google uses three main signals to rank local businesses: relevance, distance, and prominence. Of these, prominence is the one you have the most control over.
            </p>
            <ul className="space-y-3 text-base text-black/70 mb-6 list-none pl-0">
              {['Optimise your Google Business Profile completely', 'Build consistent local citations', 'Earn genuine customer reviews', 'Create locally-relevant website content', 'Build local backlinks'].map(item => (
                <li key={item} className="flex items-start gap-2">
                  <span className="text-[#623ccc] font-bold mt-0.5">→</span>
                  {item}
                </li>
              ))}
            </ul>
            <p className="text-base text-black/70 leading-relaxed">
              Each of these signals compounds over time. The businesses that rank at the top of Google Maps in your city have been building these signals consistently for months or years.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
