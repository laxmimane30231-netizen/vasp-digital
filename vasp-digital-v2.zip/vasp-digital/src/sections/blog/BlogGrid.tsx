'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

const posts = [
  { slug: 'rank-google-maps', category: 'Local SEO', title: 'How to rank in Google Maps: Strategies for local visibility', excerpt: 'Google Maps is where local customers decide who to call. Here is exactly what it takes to rank in the local pack in 2024.', date: 'March 12, 2024', readTime: '8 min read' },
  { slug: 'google-ads-local-business', category: 'Paid Ads', title: 'Google Ads for local businesses: a complete starter guide', excerpt: 'You do not need a massive budget to run effective Google Ads. Here is how local businesses can start with confidence.', date: 'February 28, 2024', readTime: '10 min read' },
  { slug: 'seo-vs-paid-ads', category: 'Strategy', title: 'SEO vs Paid Ads: which should you invest in first?', excerpt: 'Both work. But the right answer depends on your timeline, budget, and goals. Here is how to decide.', date: 'February 14, 2024', readTime: '6 min read' },
  { slug: 'gbp-optimisation', category: 'Local SEO', title: 'Google Business Profile optimisation: the complete checklist', excerpt: 'Your GBP is your most powerful local marketing tool — and most businesses leave it half-finished.', date: 'January 30, 2024', readTime: '7 min read' },
  { slug: 'website-converts', category: 'Web Design', title: 'What makes a local business website actually convert', excerpt: 'Traffic means nothing without conversions. Here are the elements that turn visitors into customers.', date: 'January 15, 2024', readTime: '5 min read' },
  { slug: 'local-citations-guide', category: 'Local SEO', title: 'Local citations: why they matter and how to build them', excerpt: 'Citations are a foundational part of local SEO. Here is how to build them correctly and avoid common mistakes.', date: 'January 2, 2024', readTime: '6 min read' },
];

export default function BlogGrid() {
  return (
    <section className="bg-white py-16 lg:py-20">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post, i) => (
            <motion.article
              key={post.slug}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.06, ease: 'easeOut' }}
              className="group"
            >
              <Link href={`/blog/${post.slug}`}>
                <div className="rounded-2xl overflow-hidden bg-[#f1f1f1] aspect-[16/9] mb-4 group-hover:shadow-md transition-shadow flex items-center justify-center">
                  <span className="text-black/20 text-xs">Article image</span>
                </div>
              </Link>
              <SectionLabel className="mb-2 text-[#623ccc]">{post.category}</SectionLabel>
              <Link href={`/blog/${post.slug}`}>
                <h2 className="text-lg font-bold leading-snug mb-2 group-hover:text-[#623ccc] transition-colors">
                  {post.title}
                </h2>
              </Link>
              <p className="text-black/60 text-sm leading-relaxed mb-4">{post.excerpt}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-black/40">{post.date} · {post.readTime}</span>
                <Link href={`/blog/${post.slug}`} className="inline-flex items-center gap-1 text-xs font-semibold hover:text-[#623ccc] transition-colors">
                  Read <ArrowRight size={12} />
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
