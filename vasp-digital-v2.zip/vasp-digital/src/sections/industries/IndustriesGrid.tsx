'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

const industries = [
  { slug: 'clinics', name: 'Clinics & Healthcare', description: 'Patients find you through local search and Google Ads. We help healthcare practices fill their schedules.', icon: '🏥' },
  { slug: 'contractors', name: 'Contractors & Trades', description: 'Rank for service calls in your area and get qualified leads from people ready to hire.', icon: '🔧' },
  { slug: 'legal', name: 'Legal Services', description: 'Build authority and attract high-value clients consistently through SEO and targeted ads.', icon: '⚖️' },
  { slug: 'real-estate', name: 'Real Estate', description: 'List properties where buyers search and attract sellers through local authority.', icon: '🏠' },
  { slug: 'restaurants', name: 'Restaurants & Food', description: 'Get found when hungry locals search for what you serve. Drive reservations and walk-ins.', icon: '🍽️' },
  { slug: 'home-services', name: 'Home Services', description: 'Plumbers, HVAC, electricians — show up when homeowners need you most.', icon: '🏡' },
];

export default function IndustriesGrid() {
  return (
    <section className="bg-white py-16 lg:py-24">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {industries.map((ind, i) => (
            <motion.div
              key={ind.slug}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08, ease: 'easeOut' }}
              className="group p-8 rounded-2xl bg-[#f1f1f1] hover:bg-[#f0ecff] transition-colors"
            >
              <div className="text-3xl mb-4">{ind.icon}</div>
              <h3 className="text-lg font-bold mb-2">{ind.name}</h3>
              <p className="text-black/60 text-sm leading-relaxed mb-5">{ind.description}</p>
              <Link href={`/industries/${ind.slug}`} className="inline-flex items-center gap-1.5 text-sm font-semibold hover:text-[#623ccc] transition-colors">
                Learn more <ArrowRight size={14} />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
