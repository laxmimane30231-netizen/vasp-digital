'use client';
import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';

export default function IndustriesHero() {
  return (
    <section className="bg-[#fd7056] text-white pt-16">
      <div className="container py-16 lg:py-24">
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: 'easeOut' }} className="max-w-3xl">
          <SectionLabel light className="mb-4">Industries</SectionLabel>
          <h1 className="text-[44px] md:text-[56px] font-bold leading-tight tracking-tight mb-4">
            We work with businesses across every sector
          </h1>
          <p className="text-white/80 text-base lg:text-lg max-w-xl">
            From clinics to contractors, legal firms to real estate. If you need more leads and better visibility, we have helped businesses like yours.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
