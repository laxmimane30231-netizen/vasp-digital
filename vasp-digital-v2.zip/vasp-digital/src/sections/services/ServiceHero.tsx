'use client';

import { motion } from 'framer-motion';
import Button from '@/components/ui/Button';
import SectionLabel from '@/components/ui/SectionLabel';

interface ServiceHeroProps {
  label: string;
  title: string;
  description: string;
  primaryCTA?: { label: string; href: string };
  secondaryCTA?: { label: string; href: string };
  variant?: 'purple' | 'dark' | 'grey' | 'coral';
}

export default function ServiceHero({
  label,
  title,
  description,
  primaryCTA = { label: 'Talk', href: '/contact?type=call' },
  secondaryCTA = { label: 'Audit', href: '/contact?type=audit' },
  variant = 'dark' as 'purple' | 'dark' | 'grey' | 'coral',
}: ServiceHeroProps) {
  const bgMap = {
    purple: 'bg-[#623ccc] text-white',
    dark: 'bg-black text-white',
    grey: 'bg-[#f1f1f1] text-black',
    coral: 'bg-[#fd7056] text-white',
  };

  return (
    <section className={`${bgMap[variant]} pt-16`}>
      <div className="container py-16 lg:py-24">
        <motion.div
          className="max-w-3xl"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <SectionLabel className={`mb-4 ${variant !== 'grey' ? 'text-white/60' : 'text-black/50'}`}>
            {label}
          </SectionLabel>
          <h1 className="text-[40px] md:text-[52px] lg:text-[64px] xl:text-[72px] font-bold leading-tight tracking-tight mb-6">
            {title}
          </h1>
          <p className={`text-base lg:text-lg leading-relaxed mb-8 max-w-xl ${variant !== 'grey' ? 'text-white/70' : 'text-black/60'}`}>
            {description}
          </p>
          <div className="flex flex-wrap gap-3">
            <Button variant={variant !== 'grey' ? 'white' : 'secondary'} size="md" href={primaryCTA.href}>
              {primaryCTA.label}
            </Button>
            <Button
              variant="ghost"
              size="md"
              href={secondaryCTA.href}
              className={variant !== 'grey' ? 'text-white hover:bg-white/10' : ''}
            >
              {secondaryCTA.label}
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
