'use client';

import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';
import {
  TrendingUp, Search, Link2, BarChart2, MapPin, FileText,
  Target, DollarSign, Users, Zap, RefreshCw, Monitor,
  Smartphone, Shield, Star, Building2, Globe, Phone,
} from 'lucide-react';

export type FeatureIconName =
  | 'TrendingUp' | 'Search' | 'Link2' | 'BarChart2' | 'MapPin' | 'FileText'
  | 'Target' | 'DollarSign' | 'Users' | 'Zap' | 'RefreshCw' | 'Monitor'
  | 'Smartphone' | 'Shield' | 'Star' | 'Building2' | 'Globe' | 'Phone';

const iconMap: Record<FeatureIconName, React.ElementType> = {
  TrendingUp, Search, Link2, BarChart2, MapPin, FileText,
  Target, DollarSign, Users, Zap, RefreshCw, Monitor,
  Smartphone, Shield, Star, Building2, Globe, Phone,
};

export interface Feature {
  icon?: FeatureIconName;
  title: string;
  description: string;
}

interface ServiceFeaturesProps {
  label?: string;
  title: string;
  description?: string;
  features: Feature[];
  columns?: 2 | 3 | 4;
}

export default function ServiceFeatures({
  label,
  title,
  description,
  features,
  columns = 3,
}: ServiceFeaturesProps) {
  const colMap = {
    2: 'md:grid-cols-2',
    3: 'md:grid-cols-3',
    4: 'md:grid-cols-2 lg:grid-cols-4',
  };

  return (
    <section className="bg-white py-16 lg:py-24 border-t border-black/10">
      <div className="container">
        <motion.div
          className="max-w-2xl mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        >
          {label && <SectionLabel className="mb-3">{label}</SectionLabel>}
          <h2 className="text-[28px] md:text-[36px] lg:text-[44px] font-bold leading-tight tracking-tight mb-3">
            {title}
          </h2>
          {description && <p className="text-black/60 text-base leading-relaxed">{description}</p>}
        </motion.div>

        <div className={`grid grid-cols-1 ${colMap[columns]} gap-6`}>
          {features.map((feat, i) => {
            const Icon = feat.icon ? iconMap[feat.icon] : null;
            return (
              <motion.div
                key={feat.title}
                className="p-6 rounded-2xl bg-[#f1f1f1] hover:bg-[#f0ecff] transition-colors"
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08, ease: 'easeOut' }}
              >
                {Icon && (
                  <div className="w-10 h-10 rounded-xl bg-[#e3dbff] flex items-center justify-center mb-4">
                    <Icon size={18} className="text-[#623ccc]" />
                  </div>
                )}
                <h3 className="text-base font-bold mb-2">{feat.title}</h3>
                <p className="text-black/60 text-sm leading-relaxed">{feat.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
