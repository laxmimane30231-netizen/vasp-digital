'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';

const serviceGroups = [
  {
    tag: 'Organic',
    title: 'SEO services',
    description: 'Rank higher and own organic search results',
    href: '/services/seo',
    cta: 'Explore',
    color: 'bg-[#f0ecff]',
    wide: true,
  },
  {
    tag: 'Local',
    title: 'Local SEO',
    description: 'Get found by customers searching near you',
    href: '/services/local-seo',
    cta: 'Explore',
    color: 'bg-[#f1f1f1]',
  },
  {
    tag: 'Paid',
    title: 'Google Ads and paid advertising',
    description: 'Drive qualified traffic and leads immediately',
    href: '/services/paid-ads',
    cta: 'Explore',
    color: 'bg-[#f1f1f1]',
  },
  {
    tag: 'Web',
    title: 'Web design and development',
    description: 'Build a site that converts visitors to clients',
    href: '/services/web-design',
    cta: 'Learn',
    color: 'bg-[#f0ecff]',
  },
  {
    tag: 'Growth',
    title: 'Rank in organic search',
    description: 'Build a site that converts visitors to clients',
    href: '/services/seo',
    cta: 'Explore',
    color: 'bg-[#e3dbff]',
  },
];

export default function ServiceGrid() {
  return (
    <section className="bg-white py-16 lg:py-24 border-t border-black/10">
      <div className="container">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-[28px] md:text-[36px] lg:text-[44px] font-bold leading-tight tracking-tight mb-3">
            Our services
          </h2>
          <p className="text-black/60 text-base max-w-xl mx-auto">
            The right digital strategy can transform your business. Explore our core services designed to deliver visibility, traffic, and leads for local businesses.
          </p>
        </motion.div>

        {/* Services label section */}
        <div className="mb-10 p-8 rounded-2xl bg-[#f0ecff]">
          <SectionLabel className="mb-3">Services</SectionLabel>
          <h3 className="text-[24px] md:text-[28px] font-bold tracking-tight mb-2">Four ways to grow</h3>
          <p className="text-black/60 text-sm">Pick your path or combine them all</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {serviceGroups.map((service, i) => (
            <motion.div
              key={service.title}
              className={`p-8 rounded-2xl ${service.color} group hover:shadow-sm transition-shadow ${service.wide ? 'md:col-span-2 lg:col-span-1' : ''}`}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
            >
              <SectionLabel className="mb-3 text-[#623ccc]">{service.tag}</SectionLabel>
              <h3 className="text-xl md:text-2xl font-bold mb-2 tracking-tight">{service.title}</h3>
              <p className="text-black/60 text-sm mb-5">{service.description}</p>

              {/* Image placeholder */}
              <div className="rounded-xl overflow-hidden bg-black/5 aspect-video mb-5 flex items-center justify-center">
                <span className="text-black/20 text-xs">{service.title} visual</span>
              </div>

              <Link
                href={service.href}
                className="inline-flex items-center gap-1.5 text-sm font-semibold hover:text-[#623ccc] transition-colors"
              >
                {service.cta} <ArrowRight size={14} />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
