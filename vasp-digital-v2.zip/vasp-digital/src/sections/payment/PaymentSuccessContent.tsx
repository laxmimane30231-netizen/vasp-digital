'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { CheckCircle, ArrowRight } from 'lucide-react';

export default function PaymentSuccessContent() {
  const [sessionId, setSessionId] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setSessionId(params.get('session_id') ?? '');
  }, []);

  return (
    <section className="min-h-screen bg-[#f0ecff] flex items-center justify-center px-6 pt-16">
      <motion.div
        className="text-center max-w-lg"
        initial={{ opacity: 0, scale: 0.94 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
          className="w-20 h-20 bg-[#623ccc] rounded-full flex items-center justify-center mx-auto mb-6"
        >
          <CheckCircle size={40} className="text-white" />
        </motion.div>

        <h1 className="text-[36px] md:text-[44px] font-bold tracking-tight mb-4">
          Payment successful!
        </h1>
        <p className="text-black/60 text-base leading-relaxed mb-8">
          Thank you for choosing VASP Digital. Your payment has been processed and your
          service is now active. You&apos;ll receive a confirmation email shortly.
        </p>

        <div className="bg-white rounded-2xl p-6 mb-8 text-left">
          <h3 className="font-bold text-sm mb-3">What happens next</h3>
          <ul className="space-y-2.5">
            {[
              'You\'ll receive a confirmation email within a few minutes',
              'Our team will reach out within 1 business day to get started',
              'We\'ll schedule an onboarding call to understand your goals',
              'Your campaign or service kicks off within 5 business days',
            ].map((step, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-black/65">
                <span className="w-5 h-5 bg-[#e3dbff] text-[#623ccc] rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                  {i + 1}
                </span>
                {step}
              </li>
            ))}
          </ul>
        </div>

        {sessionId && (
          <p className="text-xs text-black/30 mb-6">Reference: {sessionId}</p>
        )}

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/"
            className="px-6 py-3 bg-black text-white rounded-full text-sm font-semibold hover:bg-[#623ccc] transition-colors"
          >
            Back to home
          </Link>
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 px-6 py-3 border border-black/20 rounded-full text-sm font-semibold hover:border-black transition-colors"
          >
            Contact us <ArrowRight size={14} />
          </Link>
        </div>
      </motion.div>
    </section>
  );
}
