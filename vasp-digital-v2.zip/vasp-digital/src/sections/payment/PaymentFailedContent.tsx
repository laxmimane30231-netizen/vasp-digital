'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { AlertCircle } from 'lucide-react';

export default function PaymentFailedContent() {
  return (
    <section className="min-h-screen bg-red-50 flex items-center justify-center px-6 pt-16">
      <motion.div
        className="text-center max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
      >
        <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <AlertCircle size={40} className="text-red-500" />
        </div>
        <h1 className="text-[32px] md:text-[40px] font-bold tracking-tight mb-4">
          Payment failed
        </h1>
        <p className="text-black/55 text-base leading-relaxed mb-6">
          There was an issue processing your payment. This can happen if your card was
          declined or there was a temporary issue. No charge was made.
        </p>
        <div className="bg-white rounded-2xl p-5 mb-8 text-left">
          <h3 className="font-bold text-sm mb-2">Common reasons for failure</h3>
          <ul className="space-y-1.5 text-sm text-black/55">
            <li>• Insufficient funds on the card</li>
            <li>• Card number, expiry, or CVV entered incorrectly</li>
            <li>• Card issuer declined the international transaction</li>
            <li>• Temporary issue with your bank</li>
          </ul>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/services"
            className="px-6 py-3 bg-black text-white rounded-full text-sm font-semibold hover:bg-[#623ccc] transition-colors"
          >
            Try again
          </Link>
          <Link
            href="/contact"
            className="px-6 py-3 border border-black/20 rounded-full text-sm font-semibold hover:border-black transition-colors"
          >
            Contact support
          </Link>
        </div>
      </motion.div>
    </section>
  );
}
