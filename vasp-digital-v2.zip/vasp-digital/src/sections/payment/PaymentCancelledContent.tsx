'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { XCircle } from 'lucide-react';

export default function PaymentCancelledContent() {
  return (
    <section className="min-h-screen bg-[#f1f1f1] flex items-center justify-center px-6 pt-16">
      <motion.div
        className="text-center max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
      >
        <div className="w-20 h-20 bg-black/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <XCircle size={40} className="text-black/40" />
        </div>
        <h1 className="text-[32px] md:text-[40px] font-bold tracking-tight mb-4">
          Payment cancelled
        </h1>
        <p className="text-black/55 text-base leading-relaxed mb-8">
          No charge was made. You can go back and try again whenever you&apos;re ready,
          or contact us if you have any questions about our packages.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/services"
            className="px-6 py-3 bg-black text-white rounded-full text-sm font-semibold hover:bg-[#623ccc] transition-colors"
          >
            View packages
          </Link>
          <Link
            href="/contact"
            className="px-6 py-3 border border-black/20 rounded-full text-sm font-semibold hover:border-black transition-colors"
          >
            Talk to us first
          </Link>
        </div>
      </motion.div>
    </section>
  );
}
