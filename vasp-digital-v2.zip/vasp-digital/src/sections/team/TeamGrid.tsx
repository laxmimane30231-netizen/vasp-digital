'use client';
import { motion } from 'framer-motion';
import { ExternalLink } from "lucide-react";

const team = [
  { name: 'Alex Vander', role: 'Founder & Strategy Lead', bio: 'Built VASP Digital to give local businesses access to enterprise-level marketing strategy.', linkedin: '#' },
  { name: 'Sarah Park', role: 'SEO Specialist', bio: 'Five years of local SEO expertise. Has ranked businesses in some of Ontario\'s most competitive markets.', linkedin: '#' },
  { name: 'Mike Torres', role: 'Paid Ads Manager', bio: 'Managed Google Ads budgets from $1k to $50k/month. Knows how to make every dollar count.', linkedin: '#' },
  { name: 'Jordan Lee', role: 'Web Developer', bio: 'Builds fast, SEO-ready websites that actually convert visitors into customers.', linkedin: '#' },
];

export default function TeamGrid() {
  return (
    <section className="bg-white py-16 lg:py-24">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {team.map((member, i) => (
            <motion.div
              key={member.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1, ease: 'easeOut' }}
            >
              <div className="rounded-2xl overflow-hidden aspect-[3/4] bg-[#e3dbff] mb-4 flex items-center justify-center">
                <span className="text-[#623ccc]/30 text-sm">Photo</span>
              </div>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-base">{member.name}</h3>
                  <p className="text-xs text-black/50 mb-2">{member.role}</p>
                </div>
                <a href={member.linkedin} className="text-black/30 hover:text-[#623ccc] transition-colors mt-0.5">
                  <ExternalLink size={16} />
                </a>
              </div>
              <p className="text-sm text-black/60 leading-relaxed">{member.bio}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
