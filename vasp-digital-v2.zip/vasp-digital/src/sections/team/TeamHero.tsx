'use client';
import { motion } from 'framer-motion';
import SectionLabel from '@/components/ui/SectionLabel';

export default function TeamHero() {
  return (
    <section className="bg-[#623ccc] text-white pt-16">
      <div className="container py-16 lg:py-24">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        >
          <SectionLabel light className="mb-4">Team</SectionLabel>
          <h1 className="text-[44px] md:text-[56px] font-bold leading-tight tracking-tight mb-4">
            The people behind your growth
          </h1>
          <p className="text-white/70 text-base lg:text-lg max-w-xl">
            A small, focused team of digital marketing specialists. Everyone here does real work on real campaigns.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
