'use client';

import { motion } from 'framer-motion';
import { Mail, Phone, MapPin } from 'lucide-react';
import Link from 'next/link';
import SectionLabel from '@/components/ui/SectionLabel';

export default function ContactInfo() {
  return (
    <section className="bg-white py-16 lg:py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <SectionLabel className="mb-2">Reach</SectionLabel>
          <h2 className="text-[28px] md:text-[36px] font-bold tracking-tight mb-2">Get in touch</h2>
          <p className="text-black/60 text-sm">We&apos;re based in London, Ontario and serve the GTA.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-lg bg-[#f0ecff] flex items-center justify-center shrink-0">
                <Mail size={16} className="text-[#623ccc]" />
              </div>
              <div>
                <div className="text-sm font-semibold mb-0.5">Email</div>
                <p className="text-black/60 text-xs mb-1">Send us a message anytime.</p>
                <a href="mailto:hello@vaspdigital.com" className="text-sm font-medium text-[#623ccc] hover:underline">
                  hello@vaspdigital.com
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-lg bg-[#f0ecff] flex items-center justify-center shrink-0">
                <Phone size={16} className="text-[#623ccc]" />
              </div>
              <div>
                <div className="text-sm font-semibold mb-0.5">Phone</div>
                <p className="text-black/60 text-xs mb-1">Call us during business hours.</p>
                <a href="tel:+17059020000" className="text-sm font-medium text-[#623ccc] hover:underline">
                  +1 (705) 902-0000
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-lg bg-[#f0ecff] flex items-center justify-center shrink-0">
                <MapPin size={16} className="text-[#623ccc]" />
              </div>
              <div>
                <div className="text-sm font-semibold mb-0.5">Office</div>
                <p className="text-black/60 text-xs mb-1">133 King Street, London, Ontario N6A 1KI</p>
                <Link href="https://maps.google.com" target="_blank" className="text-sm font-medium text-[#623ccc] hover:underline">
                  Get directions →
                </Link>
              </div>
            </div>
          </div>

          {/* Map placeholder */}
          <div className="rounded-2xl overflow-hidden bg-[#f1f1f1] min-h-[220px] flex items-center justify-center">
            <div className="text-center text-black/30">
              <MapPin size={32} className="mx-auto mb-2 opacity-30" />
              <span className="text-sm">Map embed</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
