'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { CheckCircle, ArrowRight } from 'lucide-react';

export default function ThankYouContent() {
  return (
    <section className="bg-[#623ccc] text-white min-h-screen flex items-center pt-16">
      <div className="container py-20 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        >
          <CheckCircle size={64} className="mx-auto mb-6 text-white/80" />
          <h1 className="text-[44px] md:text-[56px] font-bold leading-tight tracking-tight mb-4">
            Message received
          </h1>
          <p className="text-white/70 text-base lg:text-lg max-w-md mx-auto mb-10">
            Thanks for getting in touch. We will review your message and get back to you within 24 business hours.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/" className="px-6 py-3 bg-white text-black text-sm font-semibold rounded-full hover:bg-[#f0ecff] transition-colors">
              Back to home
            </Link>
            <Link href="/blog" className="inline-flex items-center gap-1.5 text-sm font-semibold text-white/80 hover:text-white transition-colors">
              Read the blog <ArrowRight size={14} />
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
