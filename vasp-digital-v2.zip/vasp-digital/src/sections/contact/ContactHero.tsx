'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import SectionLabel from '@/components/ui/SectionLabel';

export default function ContactHero() {
  return (
    <section className="bg-[#623ccc] text-white pt-16">
      <div className="container py-16 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <SectionLabel light className="mb-4">Connect</SectionLabel>
            <h1 className="text-[44px] md:text-[52px] lg:text-[64px] font-bold leading-tight tracking-tight">
              Let&apos;s talk growth
            </h1>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
          >
            <p className="text-white/80 text-base lg:text-lg leading-relaxed mb-8">
              Tell us about your business and what you need. We&apos;ll listen, ask the right questions, and show you how we can help generate more leads through search and paid advertising. No pitch. Just honest conversation about what&apos;s possible.
            </p>
            <div className="flex items-center gap-3">
              <Link
                href="tel:+17059020000"
                className="px-6 py-3 bg-white text-black text-sm font-semibold rounded-full hover:bg-[#f0ecff] transition-colors"
              >
                Call
              </Link>
              <Link
                href="#message"
                className="px-6 py-3 bg-white/20 text-white text-sm font-semibold rounded-full hover:bg-white/30 transition-colors"
              >
                Message
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
