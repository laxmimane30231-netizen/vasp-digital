'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import SectionLabel from '@/components/ui/SectionLabel';
import Button from '@/components/ui/Button';

interface FormState {
  name: string;
  email: string;
  phone: string;
  company: string;
  message: string;
  agreed: boolean;
}

export default function ContactForm() {
  const [form, setForm] = useState<FormState>({ name: '', email: '', phone: '', company: '', message: '', agreed: false });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const set = (key: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [key]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    setErrorMsg('');

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, source: new URLSearchParams(window.location.search).get('type') ?? 'contact' }),
      });

      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data.error ?? 'Something went wrong. Please try again.');
        setStatus('error');
        return;
      }

      setStatus('success');
      // Redirect to thank you page
      window.location.href = '/thank-you';
    } catch {
      setErrorMsg('Something went wrong. Please try again.');
      setStatus('error');
    }
  };

  const inputClass = 'w-full px-4 py-3 bg-white border border-black/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#623ccc] focus:border-transparent transition placeholder:text-black/30';

  return (
    <section id="message" className="bg-[#f0ecff] py-16 lg:py-20">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          >
            <SectionLabel className="mb-3">Let&apos;s talk</SectionLabel>
            <h2 className="text-[28px] md:text-[36px] font-bold tracking-tight mb-3">Send us a message</h2>
            <p className="text-black/60 text-sm leading-relaxed mb-8">
              Fill out the form below and we&apos;ll get back to you within 24 hours. Tell us about your business, your goals, and what brings you here.
            </p>

            {status === 'success' ? (
              <div className="p-8 bg-white rounded-2xl text-center">
                <CheckCircle size={40} className="mx-auto mb-3 text-[#623ccc]" />
                <h3 className="font-bold text-lg mb-1">Message sent!</h3>
                <p className="text-black/60 text-sm">We&apos;ll get back to you within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-1.5">Name <span className="text-red-500">*</span></label>
                    <input type="text" required value={form.name} onChange={set('name')} className={inputClass} placeholder="Your name" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1.5">Email <span className="text-red-500">*</span></label>
                    <input type="email" required value={form.email} onChange={set('email')} className={inputClass} placeholder="you@example.com" />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-1.5">Phone</label>
                    <input type="tel" value={form.phone} onChange={set('phone')} className={inputClass} placeholder="+1 (000) 000-0000" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1.5">Company</label>
                    <input type="text" value={form.company} onChange={set('company')} className={inputClass} placeholder="Your business name" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1.5">Message <span className="text-red-500">*</span></label>
                  <textarea
                    required rows={5} value={form.message} onChange={set('message')}
                    className={`${inputClass} resize-none`}
                    placeholder="Tell us about your business and what you need help with..."
                  />
                </div>
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox" id="agree" required
                    checked={form.agreed}
                    onChange={e => setForm(f => ({ ...f, agreed: e.target.checked }))}
                    className="mt-0.5 w-4 h-4 accent-[#623ccc]"
                  />
                  <label htmlFor="agree" className="text-xs text-black/60 leading-relaxed">
                    I agree to the <a href="/privacy-policy" className="underline hover:text-[#623ccc]">privacy policy</a> and consent to being contacted about my inquiry.
                  </label>
                </div>
                {status === 'error' && (
                  <p className="text-red-500 text-sm">{errorMsg}</p>
                )}
                <Button type="submit" variant="secondary" size="md" disabled={status === 'submitting'}>
                  {status === 'submitting' ? 'Sending...' : 'Send message'}
                </Button>
              </form>
            )}
          </motion.div>

          {/* Decorative panel */}
          <motion.div
            className="hidden lg:flex flex-col gap-6"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1, ease: 'easeOut' }}
          >
            <div className="flex-1 rounded-2xl overflow-hidden bg-[#e3dbff] flex items-center justify-center">
              <span className="text-[#623ccc]/30 text-sm">Office / team photo</span>
            </div>
            <div className="rounded-2xl bg-white p-6">
              <p className="text-sm font-semibold mb-1">Expect a reply within 24 hours</p>
              <p className="text-xs text-black/60">We read every message. No auto-responses, no call centres — just real people who want to help your business grow.</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
