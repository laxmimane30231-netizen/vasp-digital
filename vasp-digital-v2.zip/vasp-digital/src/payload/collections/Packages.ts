import type { CollectionConfig } from 'payload';

const currencyOptions = [
  { label: 'USD — US Dollar',         value: 'USD' },
  { label: 'CAD — Canadian Dollar',   value: 'CAD' },
  { label: 'GBP — British Pound',     value: 'GBP' },
  { label: 'EUR — Euro',              value: 'EUR' },
  { label: 'AUD — Australian Dollar', value: 'AUD' },
];

const packageTypeOptions = [
  { label: 'SEO Package',          value: 'seo' },
  { label: 'Local SEO Package',    value: 'local-seo' },
  { label: 'Link Building Package',value: 'link-building' },
  { label: 'Paid Ads Package',     value: 'paid-ads' },
  { label: 'Web Design Package',   value: 'web-design' },
];

export const PackagesCollection: CollectionConfig = {
  slug: 'packages',
  admin: {
    useAsTitle: 'title',
    defaultColumns: ['title', 'packageType', 'basePrice', 'baseCurrency', 'isPopular', 'status'],
    description: 'Manage service packages. Prices update on the website instantly when saved.',
  },
  access: { read: () => true },
  fields: [
    // ─── Identity ──────────────────────────────────────────────────────────
    { name: 'title', type: 'text', required: true, label: 'Package Name' },
    { name: 'slug',  type: 'text', required: true, unique: true, admin: { position: 'sidebar', description: 'URL-safe identifier e.g. seo-starter' } },
    { name: 'packageType', type: 'select', required: true, options: packageTypeOptions, label: 'Package Type', admin: { position: 'sidebar' } },
    { name: 'status', type: 'select', required: true, options: [{ label: 'Active', value: 'active' }, { label: 'Archived', value: 'archived' }], defaultValue: 'active', admin: { position: 'sidebar' } },

    // ─── Display ───────────────────────────────────────────────────────────
    { name: 'description', type: 'textarea', required: true },
    { name: 'isPopular',    type: 'checkbox', defaultValue: false, label: 'Show "Most Popular" badge', admin: { position: 'sidebar' } },
    { name: 'displayOrder', type: 'number',   defaultValue: 0, admin: { position: 'sidebar', description: 'Lower = shown first' } },
    { name: 'buttonText',   type: 'text',     defaultValue: 'Get started', label: 'CTA Button Text' },
    { name: 'billingPeriod', type: 'select', options: [
      { label: 'One-time payment', value: 'one-time' },
      { label: 'Monthly',          value: 'monthly' },
      { label: 'Annual',           value: 'annual' },
    ], defaultValue: 'monthly' },

    // ─── Base Pricing ──────────────────────────────────────────────────────
    {
      name: 'pricing',
      type: 'group',
      label: 'Pricing',
      fields: [
        { name: 'basePrice',    type: 'number', required: true, label: 'Base Price',    admin: { description: 'Used as fallback for all currencies' } },
        { name: 'baseCurrency', type: 'select', required: true, options: currencyOptions, defaultValue: 'CAD', label: 'Base Currency' },
        {
          name: 'countryPricing',
          type: 'array',
          label: 'Per-Currency Pricing',
          admin: { description: 'Override price for specific currencies. If a visitor\'s currency matches, this price is shown.' },
          fields: [
            { name: 'currency', type: 'select', required: true, options: currencyOptions },
            { name: 'price',    type: 'number', required: true },
          ],
        },
      ],
    },

    // ─── Stripe ────────────────────────────────────────────────────────────
    {
      name: 'stripe',
      type: 'group',
      label: 'Stripe Integration',
      admin: { description: 'After creating prices in Stripe, paste the Price IDs here.' },
      fields: [
        { name: 'productId', type: 'text', label: 'Stripe Product ID', admin: { description: 'prod_xxx from Stripe dashboard' } },
        { name: 'priceIdUSD', type: 'text', label: 'Stripe Price ID — USD' },
        { name: 'priceIdCAD', type: 'text', label: 'Stripe Price ID — CAD' },
        { name: 'priceIdGBP', type: 'text', label: 'Stripe Price ID — GBP' },
        { name: 'priceIdEUR', type: 'text', label: 'Stripe Price ID — EUR' },
        { name: 'priceIdAUD', type: 'text', label: 'Stripe Price ID — AUD' },
      ],
    },

    // ─── Features ──────────────────────────────────────────────────────────
    {
      name: 'features',
      type: 'array',
      required: true,
      label: 'Package Features',
      fields: [
        { name: 'text',     type: 'text',     required: true, label: 'Feature description' },
        { name: 'included', type: 'checkbox', defaultValue: true, label: 'Included (unchecked = crossed out)' },
      ],
    },

    // ─── Location targeting (for Local SEO packages) ──────────────────────
    {
      name: 'locationTargeting',
      type: 'array',
      label: 'Location Targeting (Local SEO)',
      admin: { description: 'For Local SEO packages — which cities/regions this package covers.' },
      fields: [
        { name: 'location', type: 'text' },
      ],
    },
  ],
};
