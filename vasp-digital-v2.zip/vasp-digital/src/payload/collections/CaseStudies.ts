import type { CollectionConfig } from 'payload';

export const CaseStudiesCollection: CollectionConfig = {
  slug: 'case-studies',
  admin: { useAsTitle: 'title', defaultColumns: ['title', 'client'] },
  access: { read: () => true },
  fields: [
    { name: 'title', type: 'text', required: true },
    { name: 'slug', type: 'text', required: true, unique: true, admin: { position: 'sidebar' } },
    { name: 'client', type: 'text', required: true },
    { name: 'industry', type: 'text' },
    { name: 'location', type: 'text' },
    { name: 'challenge', type: 'richText' },
    { name: 'solution', type: 'richText' },
    { name: 'results', type: 'array', fields: [
      { name: 'metric', type: 'text' },
      { name: 'value', type: 'text' },
    ]},
    { name: 'featuredImage', type: 'upload', relationTo: 'media' },
    { name: 'gallery', type: 'array', fields: [{ name: 'image', type: 'upload', relationTo: 'media' }] },
    { name: 'services', type: 'array', fields: [{ name: 'service', type: 'text' }] },
    { name: 'publishDate', type: 'date', admin: { position: 'sidebar' } },
  ],
};
