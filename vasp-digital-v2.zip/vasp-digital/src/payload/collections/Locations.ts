import type { CollectionConfig } from 'payload';

export const LocationsCollection: CollectionConfig = {
  slug: 'locations',
  admin: { useAsTitle: 'city' },
  access: { read: () => true },
  fields: [
    { name: 'city', type: 'text', required: true },
    { name: 'slug', type: 'text', required: true, unique: true, admin: { position: 'sidebar' } },
    { name: 'province', type: 'text' },
    { name: 'description', type: 'textarea' },
    { name: 'content', type: 'richText' },
    { name: 'image', type: 'upload', relationTo: 'media' },
    { name: 'seo', type: 'group', fields: [
      { name: 'metaTitle', type: 'text' },
      { name: 'metaDescription', type: 'textarea' },
    ]},
  ],
};
