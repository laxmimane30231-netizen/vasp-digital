import type { CollectionConfig } from 'payload';

export const TeamCollection: CollectionConfig = {
  slug: 'team',
  admin: { useAsTitle: 'name', defaultColumns: ['name', 'designation'] },
  access: { read: () => true },
  fields: [
    { name: 'name', type: 'text', required: true },
    { name: 'designation', type: 'text', required: true },
    { name: 'bio', type: 'textarea' },
    { name: 'image', type: 'upload', relationTo: 'media' },
    { name: 'linkedin', type: 'text' },
    { name: 'order', type: 'number', admin: { position: 'sidebar' } },
  ],
};
