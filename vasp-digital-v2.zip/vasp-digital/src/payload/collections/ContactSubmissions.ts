import type { CollectionConfig } from 'payload';

export const ContactSubmissionsCollection: CollectionConfig = {
  slug: 'contact-submissions',
  admin: {
    useAsTitle: 'name',
    defaultColumns: ['name', 'email', 'createdAt', 'status'],
  },
  access: {
    create: () => true,  // Public can create (form submissions)
    read: ({ req }) => !!req.user,  // Only admins can read
    update: ({ req }) => !!req.user,
    delete: ({ req }) => !!req.user,
  },
  fields: [
    { name: 'name', type: 'text', required: true },
    { name: 'email', type: 'email', required: true },
    { name: 'phone', type: 'text' },
    { name: 'company', type: 'text' },
    { name: 'message', type: 'textarea', required: true },
    { name: 'source', type: 'text', admin: { position: 'sidebar' } },
    { name: 'status', type: 'select', options: ['new', 'contacted', 'closed'], defaultValue: 'new', admin: { position: 'sidebar' } },
  ],
  timestamps: true,
};
