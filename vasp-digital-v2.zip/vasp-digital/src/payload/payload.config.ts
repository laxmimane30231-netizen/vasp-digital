import { buildConfig } from 'payload';
import { postgresAdapter } from '@payloadcms/db-postgres';
import { lexicalEditor } from '@payloadcms/richtext-lexical';

// Collections
import { BlogCollection } from './collections/Blog';
import { TeamCollection } from './collections/Team';
import { CaseStudiesCollection } from './collections/CaseStudies';
import { ServicesCollection } from './collections/Services';
import { IndustriesCollection } from './collections/Industries';
import { LocationsCollection } from './collections/Locations';
import { TestimonialsCollection } from './collections/Testimonials';
import { ContactSubmissionsCollection } from './collections/ContactSubmissions';
import { PackagesCollection } from './collections/Packages';
import { MediaCollection } from './collections/Media';

export default buildConfig({
  secret: process.env.PAYLOAD_SECRET ?? 'fallback-dev-secret-change-in-prod',

  db: postgresAdapter({
    pool: { connectionString: process.env.DATABASE_URI },
  }),

  editor: lexicalEditor({}),

  admin: {
    meta: {
      titleSuffix: '— VASP Digital CMS',
    },
  },

  collections: [
    BlogCollection,
    TeamCollection,
    CaseStudiesCollection,
    ServicesCollection,
    IndustriesCollection,
    LocationsCollection,
    TestimonialsCollection,
    ContactSubmissionsCollection,
    PackagesCollection,
    MediaCollection,
  ],

  typescript: {
    outputFile: './src/payload/payload-types.ts',
  },
});
