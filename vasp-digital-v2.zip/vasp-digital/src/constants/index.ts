export const COLORS = {
  purple: '#623ccc',
  coral: '#fd7056',
  lavender: '#e3dbff',
  lavenderLight: '#f0ecff',
  grey: '#f1f1f1',
} as const;

export interface NavItem {
  label: string;
  description: string;
  href: string;
  isNew?: boolean;
}

export const NAV_SERVICES: NavItem[] = [
  { label: 'SEO services', description: 'Rank higher in Google search', href: '/services/seo' },
  { label: 'Local SEO', description: 'Dominate local search results', href: '/services/local-seo' },
  { label: 'Google Ads', description: 'Get leads from paid search', href: '/services/google-ads' },
  { label: 'Web design', description: 'Build websites that convert', href: '/services/web-design' },
];

export const NAV_INDUSTRIES: NavItem[] = [
  { label: 'Contractors', description: 'Get more qualified leads', href: '/industries/contractors' },
  { label: 'Clinics', description: 'Attract new patients online', href: '/industries/clinics' },
  { label: 'Legal services', description: 'Build authority and trust', href: '/industries/legal' },
  { label: 'Real estate', description: 'List properties where buyers search', href: '/industries/real-estate' },
];

export const NAV_LOCATIONS: NavItem[] = [
  { label: 'London', description: 'Digital marketing for London businesses', href: '/locations/london' },
  { label: 'Toronto', description: 'Digital marketing for Toronto businesses', href: '/locations/toronto' },
  { label: 'Mississauga', description: 'Digital marketing for Mississauga businesses', href: '/locations/mississauga' },
  { label: 'Hamilton', description: 'Digital marketing for Hamilton businesses', href: '/locations/hamilton' },
];

export const NAV_RESOURCES: NavItem[] = [
  { label: 'How to rank in Google Maps', description: 'Strategies for local visibility', href: '/blog/rank-google-maps', isNew: true },
];

export const SITE_NAME = 'VASP Digital';
export const SITE_URL = 'https://vaspdigital.com';
